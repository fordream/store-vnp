
document.addEventListener("touchmove", function(e) { e.preventDefault(); }, false);

var email_recipient = 'app@noblejohnston.com';
var is_connected = false;

function onBodyLoad()
{
    document.addEventListener("deviceready", onDeviceReady, false);
}

function onDeviceReady() { }

// Logic for page transitions and calculations
$(function() {  
  
    function processBuying(p, withMortgage)
    {
        if (withMortgage)
        {
            if (p < 200001) { fee = 792; }
            else if (p >= 200001 && p < 300001) { fee = 902; }
            else if (p >= 300001 && p < 400001) { fee = 1012;}
            else if (p >= 400001) { fee = 1122; }
        }
        else
        {
            if (p < 100001) { fee = 506; }
            else if (p >= 100001 && p < 200001) { fee = 561; }
            else if (p >= 200001 && p < 300001) { fee = 616; }
            else if (p >= 300001 && p < 400001) { fee = 671; }
            else if (p >= 400001) { fee = 726; } 
        }
        
        var partial_disbursement = p * 0.003;
        if (withMortgage)
        {
            partial_disbursement += 150;
        }
        
        disbursements = 130.20 + partial_disbursement;
        total = fee + disbursements;
    }
    
    function processSelling(p)
    {
        if (p < 100001) { fee = 506; }
        else if (p >= 100001 && p < 200001) { fee = 561;}
        else if (p >= 200001 && p < 300001) { fee = 616;}
        else if (p >= 300001 && p < 400001) { fee = 671;}
        else if (p >= 400001) { fee = 726; }
        
        disbursements = 43.05;
        total = fee + disbursements;
    }
    
    function processRefinancing(p)
    {
        if (p < 75001) { fee = 368.5; }
        else if (p >= 75001 && p < 150001) { fee = 423.5; }
        else if (p >= 150001 && p < 250001) { fee = 478.5; }
        else if (p >= 250001) { fee = 588.5; }
        
        disbursements = 291.75
        total = fee + disbursements;
    }

    $('.form').submit(function(e) {
        // Process form logic
        form = $(e.target);
        price = form.find('.price').val();
        
        // Need to handle what happens if these entries aren't filled
        if (!price) {
            navigator.notification.alert('You must specify a price.');
            return false;
        }
        
        action = form.find('.action').val();
    
        fee = 0;
        disbursements = 0;
        total = 0;
        
        switch(action)
        {
            case "buying-yes":
            default:
                processBuying(price, true);
                break;
            case "buying-no":
                processBuying(price, false);
                break;
            case "selling":
                processSelling(price);
                break;
            case "refinancing":
                processRefinancing(price);
                break;
        }
                                            
        $('#results').html('The total fee will be <br /><br /><strong>$' + total.toFixed(2) + '</strong>');
        $('#send_email_with_details').data('info', {type: action, principal: price, quote: total});
                      
        $.mobile.changePage('#calculation');
        return false;
    });
    
    $('#send_email_with_details').click(function(){
        var info = $(this).data('info');
        var action = "";
        switch(info.type)
        {
            case "buying-yes":
                action = "Buying (with Mortgage)";
                break;
            case "buying-no":
                action = "Buying (w/out Mortgage)";
                break;
            case "selling":
                action = "Selling";
                break;
            case "refinancing":
                action = "Refinancing";
                break;
        }        
        
        var body = "Action: " + action + "\nPrice: $" + info.principal + "\nQuote: $" + info.quote; 
        window.plugins.emailComposer.showEmailComposerWithCB(function(res) {

            // Do nothing
            if (res == EmailComposer.ComposeResultType.Sent) {
                $('#send_email_with_details').html('Submitted!').button('disable');
                navigator.notification.alert('Your quote has been submitted!', "NJA FeeCalc");
            }
            
            else if (res == EmailComposer.ComposeResultType.Failed) {
                navigator.notification.alert('Sending your quote failed. Please wait a minute and try again.', "NJA FeeCalc");
            }
        }, 'Quote from App', body, email_recipient);
    });
});
//
//  Point1.m
//  DiamondGame
//
//  Created by Truong Vuong on 8/9/11.
//  Copyright 2011 CNC Software. All rights reserved.
//

#import "Point1.h"


@implementation Point1

@synthesize x, y,type,magic;



-(void) dealloc{

	[super dealloc];
}

@end

//
//  Board.h
//  DiamondGame
//
//  Created by hnsunflower1807 on 8/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#define ZIZE 64;

@interface Board : NSObject {
	int board[ZIZE];
}



@end

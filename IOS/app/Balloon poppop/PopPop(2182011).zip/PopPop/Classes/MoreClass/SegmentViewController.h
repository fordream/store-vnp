/*
     File: SegmentViewController.h
 Abstract: The view controller for hosting the UISegmentedControl features of this sample.
  Version: 2.9
 
  */

#import <UIKit/UIKit.h>

@interface SegmentViewController : UIViewController
{ }

@end

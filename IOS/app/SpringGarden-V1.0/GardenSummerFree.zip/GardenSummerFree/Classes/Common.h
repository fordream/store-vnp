//
//  Common.h
//  GardenSummer
//
//  Created by Truong Vuong on 9/9/11.
//  Copyright 2011 CNC Software. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Common : NSObject {

}

//+(BOOL)	canSoundBackgrond;
//+(void)	setCanSoundBackgrond:(BOOL)sound1;

@end

//
//  UIImagePlus.h
//  VCooking
//
//   Created by namnd on 7/27/11.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIImage (UIImagePlus)

- (UIImage*)scaleToSize:(CGSize)size;

@end

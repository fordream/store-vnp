//
//  Score_item.h
//  GardenSummer
//
//  Created by Truong Vuong on 9/9/11.
//  Copyright 2011 CNC Software. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Score_item : UIViewController {

}

@end

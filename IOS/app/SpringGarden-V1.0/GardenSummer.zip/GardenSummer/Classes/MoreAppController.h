//
//  MoreAppController.h
//  GardenSummer
//
//  Created by Truong Vuong on 9/4/11.
//  Copyright 2011 CNC Software. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Setting1.h"
#import "SoundCommon.h"
#import "DBManager.h"
#import "Score.h"
#import "Point1.h"
@interface MoreAppController : UIViewController {

}
-(IBAction) loadWebView:(id)sender;
-(IBAction)onClick:(id)sender;
@end

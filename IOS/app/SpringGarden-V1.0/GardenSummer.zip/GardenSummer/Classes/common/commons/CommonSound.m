//
//  CommonSound.m
//  GardenSummer
//
//  Created by Truong Vuong on 8/30/11.
//  Copyright 2011 CNC Software. All rights reserved.
//

#import "CommonSound.h"
#import <AudioToolbox/AudioServices.h>
#import <AVFoundation/AVFoundation.h>
@implementation CommonSound
@synthesize volleyFileID, clappingFileID;


@end

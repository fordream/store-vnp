//
//  OverlapView.h
//  PikachuGameForIpad
//
//  Created by namnd on 5/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface OverlapView : UIView {

	CGPoint p1;
	CGPoint p2;
}


@end

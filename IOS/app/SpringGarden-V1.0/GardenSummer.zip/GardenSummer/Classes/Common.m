//
//  Common.m
//  GardenSummer
//
//  Created by Truong Vuong on 9/9/11.
//  Copyright 2011 CNC Software. All rights reserved.
//

#import "Common.h"

//static BOOL isTranning;
@implementation Common

@end

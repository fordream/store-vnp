//
//  HelpController.h
//  GardenSummer
//
//  Created by Truong Vuong on 9/4/11.
//  Copyright 2011 CNC Software. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SoundCommon.h"
#import "Setting1.h"


@interface HelpController : UIViewController {

}
-(IBAction)onClick :(id)sender;
@end

//
//  CompletedOrdersViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "CompletedOrdersViewController.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "KentCustomTabbar.h"
#import "DetailOrderViewController.h"
#import "TrackViewController.h"

#define HALF_MONTH_PERIOD   60.0*60*24*14       
#define MONTH_PERIOD        60.0*60*24*30       
#define QUATER_PERIOD       60.0*60*24*30*3     
#define HALF_YEAR_PERIOD    60.0*60*24*30*6     

@interface CompletedOrdersViewController ()

- (void)disSelectAllFilterBtn;
- (void)filterTableWithPeriodTime:(CGFloat)periodTime;
- (void)startFilterTable;

@end

@implementation CompletedOrdersViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
        }
        else {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
        }
        self.navigationItem.title = NSLocalizedString(@"Completed orders", @"Completed orders");
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // setup the loading indicator
    loadingIndicator = [[MBProgressHUD alloc] initWithView:self.view];
    [loadingIndicator setLabelText:@"Loading..."];
    loadingIndicator.dimBackground = YES;
    [self.view addSubview:loadingIndicator];
    
    // set up back button
    UIImage *img_on = [UIImage imageNamed:@"back-button-on.png"];
    UIImage *img_off = [UIImage imageNamed:@"back-button-off.png"];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn setImage:img_off forState:UIControlStateNormal];
    [backBtn setImage:img_on forState:UIControlStateHighlighted];
    [backBtn setFrame:CGRectMake(0, 0, img_off.size.width, img_off.size.height)];
    [backBtn addTarget:self action:@selector(backButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarBtn = [[[UIBarButtonItem alloc] initWithCustomView:backBtn] autorelease];
    self.navigationItem.leftBarButtonItem = backBarBtn;
    
    // set up log out button
    UIImage *img_logout_on = [UIImage imageNamed:@"logout-on.png"];
    UIImage *img_logout_off = [UIImage imageNamed:@"logout-off.png"];
    UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [logoutBtn setImage:img_logout_off forState:UIControlStateNormal];
    [logoutBtn setImage:img_logout_on forState:UIControlStateHighlighted];
    [logoutBtn setFrame:CGRectMake(0, 0, img_logout_off.size.width, img_logout_off.size.height)];
    [logoutBtn addTarget:self action:@selector(loggoutBtnTapped:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *logoutBarBtn = [[[UIBarButtonItem alloc] initWithCustomView:logoutBtn] autorelease];
    self.navigationItem.rightBarButtonItem = logoutBarBtn;
    
    invoiceDataArray = [[NSMutableArray alloc] init];
    /*************/
    modal = [[CompletedInvoiceDataModal alloc] init];
    modal.delegate = self;
    [modal getCurrentInvoiceList];
    [loadingIndicator show:YES];
    
    comparePeriod = 0.0;
}

- (void)viewDidUnload
{
    [filterBtn_14days release];
    filterBtn_14days = nil;
    [filterBtn_1month release];
    filterBtn_1month = nil;
    [filterBtn_3months release];
    filterBtn_3months = nil;
    [filterBtn_6months release];
    filterBtn_6months = nil;
    [invoicesTable release];
    invoicesTable = nil;
    [searchedTextField release];
    searchedTextField = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc
{
    [invoiceDataArray release];
    [backupInvoiceList release];
    [modal release];
    [loadingIndicator release];
    [filterBtn_14days release];
    [filterBtn_1month release];
    [filterBtn_3months release];
    [filterBtn_6months release];
    [invoicesTable release];
    [searchedTextField release];
    [super dealloc];
}

#pragma mark - Custom methods
- (IBAction)backButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)loggoutBtnTapped:(id)sender {
    appDelegate.isUserLoggedIn = NO;
    [appDelegate.tabBarController selectTab:1];
    UINavigationController *tab1Controller = [appDelegate.tabBarController.viewControllers objectAtIndex:1];
    [tab1Controller popToRootViewControllerAnimated:YES];
}

- (IBAction)turnOffKeyboard:(id)sender {
    [sender resignFirstResponder];
}

- (IBAction)filterBtnTapped:(id)sender {
    UIButton *btn = (UIButton *)sender;
    if (btn.selected) {
        btn.selected = !btn.selected;
        comparePeriod = 0.0;
    }
    else {
        [self disSelectAllFilterBtn];
        btn.selected = !btn.selected;
        switch (btn.tag) {
            case 1:
                comparePeriod = HALF_MONTH_PERIOD;
                break;
            case 2:
                comparePeriod = MONTH_PERIOD;
                break;
            case 3:
                comparePeriod = QUATER_PERIOD;
                break;
            default:
                comparePeriod = HALF_YEAR_PERIOD;
                break;
        }
    }
    [self startFilterTable];
}

- (void)disSelectAllFilterBtn {
    filterBtn_14days.selected = NO;
    filterBtn_1month.selected = NO;
    filterBtn_3months.selected = NO;
    filterBtn_6months.selected = NO;
}

- (void)filterTableWithPeriodTime:(CGFloat)periodTime {
    if (periodTime*comparePeriod != 0.0) {
        for (NSInteger i=invoiceDataArray.count-1; i>=0; i--) {
            CompletedInvoiceDataModal *obj = [invoiceDataArray objectAtIndex:i];
            double subtractedTime = [[NSDate date] timeIntervalSince1970]-periodTime;
            if ([obj.orderDate timeIntervalSince1970] < subtractedTime) {
                [invoiceDataArray removeObject:obj];
            }
        }    
    }
    [invoicesTable reloadData];
}

- (void)startFilterTable {
    [invoiceDataArray removeAllObjects];
    [invoiceDataArray addObjectsFromArray:backupInvoiceList];
    if (![searchedTextField.text isEqualToString:@""]) {
        for (NSInteger i=invoiceDataArray.count-1; i>=0; i--) {
            CompletedInvoiceDataModal *obj = [invoiceDataArray objectAtIndex:i];
            if (([obj.orderRef rangeOfString:searchedTextField.text options:NSCaseInsensitiveSearch].location == NSNotFound) && ([obj.orderNumber rangeOfString:searchedTextField.text options:NSCaseInsensitiveSearch].location == NSNotFound)) {
                [invoiceDataArray removeObject:obj];
            }
        }
    }
    [self filterTableWithPeriodTime:comparePeriod];
}

#pragma mark - order modal delegate
- (void)requestSuccessfullyWithDataArray:(NSArray *)responseData {
    [loadingIndicator hide:YES];
    [invoiceDataArray removeAllObjects];
    [invoiceDataArray addObjectsFromArray:responseData];
    backupInvoiceList = [invoiceDataArray copy];
    [invoicesTable reloadData];
    [self performSelector:@selector(filterBtnTapped:) withObject:filterBtn_14days];
}

- (void)requestFailed {
    [loadingIndicator hide:YES];
    ALERT_ERROR_WITH_TEXT(@"Request failed.");
}

#pragma mark - UITableViewDataSource, UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return invoiceDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *tableIdentifier = @"Invoice custom cell";
    OrderCustomCell *cell = (OrderCustomCell *)[tableView dequeueReusableCellWithIdentifier:tableIdentifier];
    if (cell == nil) {
        NSArray *nibArr = [[NSBundle mainBundle] loadNibNamed:@"OrderCustomCell" owner:nil options:nil];
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            cell = (OrderCustomCell *)[nibArr objectAtIndex:1];
        }
        else {
            cell = (OrderCustomCell *)[nibArr objectAtIndex:3];
        }
        cell.delegate = self;
    }
    NSInteger row = indexPath.row;
    // do somethings great here
    // ...
    CompletedInvoiceDataModal *obj = [invoiceDataArray objectAtIndex:row];    
    if (![obj.trackNumber isEqualToString:@""] && ![obj.trackURL isEqualToString:@""]) {
        [cell.trackBtn setHidden:NO];
    }
    else {
        [cell.trackBtn setHidden:YES];
    }
    cell.orderNumber.text = [NSString stringWithFormat:@"Order # %@", obj.orderNumber];
    cell.orderNumString = obj.orderNumber;
    cell.orderTime.text = obj.orderTime;
    cell.orderRef.text = obj.orderRef;
    cell.orderDueDate.text = obj.orderDueDate;
    cell.trackNum = obj.trackNumber;
    cell.shipmentMethod.text = obj.shipmentMethod;
    cell.tag = row;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;    
    return cell;
}

#pragma mark - custom cell delegate
- (void)orderCell:(OrderCustomCell *)cell didSelectOrderWithNumber:(NSString *)orderNumerStr {
    DetailOrderViewController *detailController = [[DetailOrderViewController alloc] initWithNibName:@"DetailOrderViewController" bundle:nil];
    detailController.isCompletedInvoice = YES;
    CompletedInvoiceDataModal *obj = [invoiceDataArray objectAtIndex:cell.tag];
    detailController.currentOrder = obj;
    [self.navigationController pushViewController:detailController animated:YES];
    [detailController release];
}

- (void)orderCell:(OrderCustomCell *)cell didTrackWithNumber:(NSString *)trackNumerStr {
    TrackViewController *controller = [[TrackViewController alloc] initWithNibName:@"TrackViewController" bundle:nil];
    CompletedInvoiceDataModal *obj = [invoiceDataArray objectAtIndex:cell.tag];
    controller.currentOrder = obj;
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
}

#pragma mark - text field delegate
//- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
//    NSLog(@"test");
//    return YES;
//}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [invoiceDataArray removeAllObjects];
    [invoiceDataArray addObjectsFromArray:backupInvoiceList];
    if (![searchedTextField.text isEqualToString:@""]) {
        for (NSInteger i=invoiceDataArray.count-1; i>=0; i--) {
            CompletedInvoiceDataModal *obj = [invoiceDataArray objectAtIndex:i];
            if (([obj.orderRef rangeOfString:searchedTextField.text options:NSCaseInsensitiveSearch].location == NSNotFound) && ([obj.orderNumber rangeOfString:searchedTextField.text options:NSCaseInsensitiveSearch].location == NSNotFound)) {
                [invoiceDataArray removeObject:obj];
            }
        }
    }
    [self filterTableWithPeriodTime:comparePeriod];
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    textField.text = @"";
    [self startFilterTable];
    return YES;
}

@end

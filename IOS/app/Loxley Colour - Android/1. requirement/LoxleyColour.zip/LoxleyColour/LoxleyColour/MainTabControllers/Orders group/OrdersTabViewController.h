//
//  OrdersTabViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GetResponseXMLFromRequestString.h"
#import "MBProgressHUD.h"
#import "CheckboxButton.h"

@class AppDelegate;

@interface OrdersTabViewController : UIViewController <GetResponseXMLFromRequestStringDelegate, UITextFieldDelegate> {
    IBOutlet UITextField *usernameTF;
    IBOutlet UITextField *passwordTF;
    IBOutlet CheckboxButton *rememberCheckbox;
    MBProgressHUD *loadingIndicator;
    AppDelegate *appDelegate;
}

- (IBAction)loginBtnTapped:(id)sender;
- (IBAction)forgotPasswordTapped:(id)sender;
- (IBAction)turnOffKeyboard:(id)sender;

@end

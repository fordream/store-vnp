//
//  DetailOrderViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "DetailOrderViewController.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "KentCustomTabbar.h"
#import "SimpleOrderDataModal.h"
#import "CompletedInvoiceDataModal.h"
#import "OrderedItemDataModal.h"
#import "ItemCustomCell.h"
#import "TrackViewController.h"

@interface DetailOrderViewController ()

- (void)updateTotalStatistic;

@end

@implementation DetailOrderViewController
@synthesize isCompletedInvoice;
@synthesize currentOrder;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
    }
    else {
        self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
    }
    if (isCompletedInvoice) {
        self.navigationItem.title = NSLocalizedString(@"Completed orders", @"Completed orders");
        [self.view addSubview:trackBtn];
        trackBtn.center = shipmentStatus.center;
        shipmentStatus.hidden = YES;
        CompletedInvoiceDataModal *currentInvoice = (CompletedInvoiceDataModal *)currentOrder;
        shipMethod.text = currentInvoice.shipmentMethod;
    }
    else {
        self.navigationItem.title = NSLocalizedString(@"Orders in progress", @"Orders in progress");
    }
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // setup the loading indicator
    loadingIndicator = [[MBProgressHUD alloc] initWithView:self.view];
    [loadingIndicator setLabelText:@"Loading..."];
    loadingIndicator.dimBackground = YES;
    [self.view addSubview:loadingIndicator];
    
    // set up back button
    UIImage *img_on = [UIImage imageNamed:@"back-button-on.png"];
    UIImage *img_off = [UIImage imageNamed:@"back-button-off.png"];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn setImage:img_off forState:UIControlStateNormal];
    [backBtn setImage:img_on forState:UIControlStateHighlighted];
    [backBtn setFrame:CGRectMake(0, 0, img_off.size.width, img_off.size.height)];
    [backBtn addTarget:self action:@selector(backButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarBtn = [[[UIBarButtonItem alloc] initWithCustomView:backBtn] autorelease];
    self.navigationItem.leftBarButtonItem = backBarBtn;
    
    // set up log out button
    UIImage *img_logout_on = [UIImage imageNamed:@"logout-on.png"];
    UIImage *img_logout_off = [UIImage imageNamed:@"logout-off.png"];
    UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [logoutBtn setImage:img_logout_off forState:UIControlStateNormal];
    [logoutBtn setImage:img_logout_on forState:UIControlStateHighlighted];
    [logoutBtn setFrame:CGRectMake(0, 0, img_logout_off.size.width, img_logout_off.size.height)];
    [logoutBtn addTarget:self action:@selector(loggoutBtnTapped:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *logoutBarBtn = [[[UIBarButtonItem alloc] initWithCustomView:logoutBtn] autorelease];
    self.navigationItem.rightBarButtonItem = logoutBarBtn;
    
    // load data to view
    orderNumber.text = [NSString stringWithFormat:@"Order # %@", currentOrder.orderNumber];
    orderDueDate.text = [NSString stringWithFormat:@"Due date: %@", currentOrder.orderDueDate];
    orderRef.text = [NSString stringWithFormat:@"Reference: %@", currentOrder.orderRef];
    orderTime.text = currentOrder.orderTime;
    
    if (isCompletedInvoice) {
        modal = [[DetailCompletedOrderDataModal alloc] init];
        [(DetailCompletedOrderDataModal *)modal setSubDelegate:self];
        CompletedInvoiceDataModal *currentInvoice = (CompletedInvoiceDataModal *)currentOrder;
        [modal getListItemOfCurrentInvoice:currentInvoice.invoiceNumber];
        if ([currentInvoice.trackNumber isEqualToString:@""] || [currentInvoice.trackURL isEqualToString:@""]) {
            [trackBtn removeFromSuperview];
        }
    }
    else {
        modal = [[DetailOrderDataModal alloc] init];
        [(DetailOrderDataModal *)modal setSubDelegate:self];
        [modal getInfoOfCurrentOrder:currentOrder.orderNumber];
        [modal getListItemOfCurrentOrder:currentOrder.orderNumber];    
    }
    
    [loadingIndicator show:YES];
    /*********/
    itemDataList = [[NSMutableArray alloc] init];
}

- (void)viewDidUnload
{
    [orderNumber release];
    orderNumber = nil;
    [orderDueDate release];
    orderDueDate = nil;
    [orderRef release];
    orderRef = nil;
    [orderTime release];
    orderTime = nil;
    [itemsTable release];
    itemsTable = nil;
    [exclVAT release];
    exclVAT = nil;
    [totalVAT release];
    totalVAT = nil;
    [inclVAT release];
    inclVAT = nil;
    [shipMethod release];
    shipMethod = nil;
    [shipmentStatus release];
    shipmentStatus = nil;
    [trackBtn release];
    trackBtn = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc
{
    [itemDataList release];
    [modal release];
    [loadingIndicator release];
    [orderNumber release];
    [orderDueDate release];
    [orderRef release];
    [orderTime release];
    [itemsTable release];
    [exclVAT release];
    [totalVAT release];
    [inclVAT release];
    [shipMethod release];
    [shipmentStatus release];
    [trackBtn release];
    [super dealloc];
}

#pragma mark - Custom methods
- (IBAction)backButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)loggoutBtnTapped:(id)sender {
    appDelegate.isUserLoggedIn = NO;
    [appDelegate.tabBarController selectTab:1];
    UINavigationController *tab1Controller = [appDelegate.tabBarController.viewControllers objectAtIndex:1];
    [tab1Controller popToRootViewControllerAnimated:YES];
}

- (IBAction)trackBtnTapped:(id)sender {
    TrackViewController *controller = [[TrackViewController alloc] initWithNibName:@"TrackViewController" bundle:nil];
    controller.currentOrder = (CompletedInvoiceDataModal *)currentOrder;
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
}

- (void)updateTotalStatistic {
    CGFloat exclVATFloat = 0.0;
    CGFloat totalVATFloat = 0.0;
    CGFloat inclVATFloat = 0.0;
    for (OrderedItemDataModal *obj in itemDataList) {
        exclVATFloat += obj.totalPayment;
        totalVATFloat += obj.totalPayment*obj.valueOfVAT/100;
    }
    inclVATFloat = exclVATFloat+totalVATFloat;
    exclVAT.text = [NSString stringWithFormat:@"£%0.2f", exclVATFloat];
    totalVAT.text = [NSString stringWithFormat:@"£%0.2f", totalVATFloat];
    inclVAT.text = [NSString stringWithFormat:@"£%0.2f", inclVATFloat];
}

#pragma mark - modal delegate
- (void)requestFailed {
    ALERT_ERROR_WITH_TEXT(@"Can not load data.");
}

- (void)requestSuccessfullyWithInfo:(NSDictionary *)infoDict {
    shipMethod.text = [infoDict objectForKey:@"shipment method"];
}

- (void)requestSuccessfullyWithListItem:(NSArray *)itemArray {
    [loadingIndicator hide:YES];
    [itemDataList removeAllObjects];
    [itemDataList addObjectsFromArray:itemArray];
    [itemsTable reloadData];
    [self updateTotalStatistic];
}

#pragma mark - UITableViewDataSource, UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return itemDataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *tableIdentifier = @"Item custom cell";
    ItemCustomCell *cell = (ItemCustomCell *)[tableView dequeueReusableCellWithIdentifier:tableIdentifier];
    if (cell == nil) {
        NSArray *nibArr = [[NSBundle mainBundle] loadNibNamed:@"ItemCustomCell" owner:nil options:nil];
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            cell = (ItemCustomCell *)[nibArr objectAtIndex:0];
        }
        else {
            cell = (ItemCustomCell *)[nibArr objectAtIndex:1];
        }
    }
    NSInteger row = indexPath.row;
    // do somethings great here
    // ...
    OrderedItemDataModal *obj = [itemDataList objectAtIndex:row];
    cell.desc.text = obj.description;
    cell.quan.text = [NSString stringWithFormat:@"%0.0f", obj.quantity];
    cell.cost.text = [NSString stringWithFormat:@"£%0.2f", obj.cost];
    cell.disc.text = [NSString stringWithFormat:@"£%0.2f", obj.discount];
    cell.tota.text = [NSString stringWithFormat:@"£%0.2f", obj.totalPayment];
    cell.vVAT.text = [NSString stringWithFormat:@"%0.1f%%", obj.valueOfVAT];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

@end

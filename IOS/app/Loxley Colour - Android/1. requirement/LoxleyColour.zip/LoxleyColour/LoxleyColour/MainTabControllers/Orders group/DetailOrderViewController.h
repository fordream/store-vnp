//
//  DetailOrderViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailOrderDataModal.h"
#import "DetailCompletedOrderDataModal.h"

@class AppDelegate;
@class MBProgressHUD;
@class SimpleOrderDataModal;

@interface DetailOrderViewController : UIViewController <DetailOrderDataModalDelegate, DetailCompletedOrderDataModalDelegate> {
    AppDelegate *appDelegate;
    MBProgressHUD * loadingIndicator;
    BOOL isCompletedInvoice;
    
    IBOutlet UILabel *orderNumber;
    IBOutlet UILabel *orderDueDate;
    IBOutlet UILabel *orderRef;
    
    IBOutlet UILabel *orderTime;
    IBOutlet UITableView *itemsTable;
    
    IBOutlet UILabel *exclVAT;
    IBOutlet UILabel *totalVAT;
    IBOutlet UILabel *inclVAT;
    
    IBOutlet UILabel *shipMethod;
    IBOutlet UILabel *shipmentStatus;
    IBOutlet UIButton *trackBtn;
    
    SimpleOrderDataModal *currentOrder;
    id modal;
    NSMutableArray *itemDataList;
}

@property (assign, nonatomic) BOOL isCompletedInvoice;
@property (assign, nonatomic) SimpleOrderDataModal *currentOrder;

- (IBAction)trackBtnTapped:(id)sender;


@end

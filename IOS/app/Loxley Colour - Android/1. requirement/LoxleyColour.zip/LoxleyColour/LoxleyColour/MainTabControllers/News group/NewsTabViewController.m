//
//  NewsTabViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "NewsTabViewController.h"
#import "AppDelegate.h"
#import "NewsDataModal.h"
#import "KentCustomTabbar.h"
#import "DetailNewsViewController.h"

@interface NewsTabViewController ()

@end

@implementation NewsTabViewController
@synthesize ui_wNews;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = NSLocalizedString(@"News", @"News");
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
        }
        else {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
        }
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate addObserver:self forKeyPath:@"isUserLoggedIn" options:(NSKeyValueObservingOptionNew) context:NULL];
    
    // set up log out button
    UIImage *img_on = [UIImage imageNamed:@"logout-on.png"];
    UIImage *img_off = [UIImage imageNamed:@"logout-off.png"];
    UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [logoutBtn setImage:img_off forState:UIControlStateNormal];
    [logoutBtn setImage:img_on forState:UIControlStateHighlighted];
    [logoutBtn setFrame:CGRectMake(0, 0, img_off.size.width, img_off.size.height)];
    [logoutBtn addTarget:self action:@selector(loggoutBtnTapped:) forControlEvents:UIControlEventTouchUpInside];
    logoutBarBtn = [[UIBarButtonItem alloc] initWithCustomView:logoutBtn];
    
    //  feed dummy data
    newsDataArray = [[NSMutableArray alloc] initWithArray:[NewsDataModal feedDummyDataWithQuantity:4]];
    [newsTable reloadData];
    [self loadContentFromWeb];
}
-(void)loadContentFromWeb
{
    NSString* strLinkToWebNews =@"http://www.loxleycolour.com/iphone/news.html";
    NSURL* urlLinkToWebNews = [NSURL URLWithString:strLinkToWebNews];
    [ui_wNews loadRequest:[NSURLRequest requestWithURL:urlLinkToWebNews]];
}
- (void)viewDidUnload
{
    [newsTable release];
    newsTable = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [appDelegate removeObserver:self forKeyPath:@"isUserLoggedIn"];
    [newsTable release];
    [logoutBarBtn release];
    [super dealloc];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if (appDelegate.isUserLoggedIn) {
        self.navigationItem.rightBarButtonItem = logoutBarBtn;
    }
    else {
        self.navigationItem.rightBarButtonItem = nil;
    }
}

#pragma mark - Custom methods
- (IBAction)loggoutBtnTapped:(id)sender {
    appDelegate.isUserLoggedIn = NO;
    [appDelegate.tabBarController selectTab:1];
    UINavigationController *tab1Controller = [appDelegate.tabBarController.viewControllers objectAtIndex:1];
    [tab1Controller popToRootViewControllerAnimated:YES];
}

#pragma mark - UITableViewDataSource, UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return newsDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *tableIdentifier = @"News cell";
    NewsCustomCell *cell = (NewsCustomCell *)[tableView dequeueReusableCellWithIdentifier:tableIdentifier];
    if (cell == nil) {
        NSArray *nibArr = [[NSBundle mainBundle] loadNibNamed:@"NewsCustomCell" owner:nil options:nil];
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            cell = (NewsCustomCell *)[nibArr objectAtIndex:0];
        }
        else {
            cell = (NewsCustomCell *)[nibArr objectAtIndex:1];
        }
        cell.delegate = self;
    }
    NSInteger row = indexPath.row;
    // do somethings great here
    // ...
    NewsDataModal *obj = [newsDataArray objectAtIndex:row];
    cell.newsTitle.text = obj.title;
    cell.newsTime.text = obj.time;
    cell.newsContent.text = obj.content;
    cell.linkURL = [NSURL URLWithString:@"http://google.com"];
    
    return cell;
}

#pragma mark -
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // do somethings great here
    // ...
    DetailNewsViewController *controller = [[DetailNewsViewController alloc] initWithNibName:@"DetailNewsViewController" bundle:nil];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
}

#pragma mark - cell delegate
- (void)didDiscoverDetailLinkOfCell:(NewsCustomCell *)cell {
    [[UIApplication sharedApplication] openURL:cell.linkURL];
}

@end

//
//  CompletedOrdersViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CompletedInvoiceDataModal.h"
#import "OrderCustomCell.h"

@class AppDelegate;
@class MBProgressHUD;

@interface CompletedOrdersViewController : UIViewController <SimpleOrderDataModalDelegate, OrderCustomCellDelegate> {
    AppDelegate *appDelegate;
    MBProgressHUD *loadingIndicator;
    IBOutlet UIButton *filterBtn_14days;
    IBOutlet UIButton *filterBtn_1month;
    IBOutlet UIButton *filterBtn_3months;
    IBOutlet UIButton *filterBtn_6months;
    CompletedInvoiceDataModal *modal;
    IBOutlet UITableView *invoicesTable;
    IBOutlet UITextField *searchedTextField;
    NSMutableArray *invoiceDataArray;
    NSArray *backupInvoiceList;
    
    CGFloat comparePeriod;
}

- (IBAction)turnOffKeyboard:(id)sender;
- (IBAction)filterBtnTapped:(id)sender;

@end

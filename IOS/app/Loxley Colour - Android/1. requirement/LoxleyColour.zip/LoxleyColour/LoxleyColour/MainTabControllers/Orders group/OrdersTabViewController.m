//
//  OrdersTabViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "OrdersTabViewController.h"
#import "ForgotPasswordViewController.h"
#import "AppDelegate.h"
#import "HomeViewController.h"
#import "TBXML.h"

@interface OrdersTabViewController ()
- (void)moveUpViewToNewLocationWithPoint:(CGPoint)point;
- (void)moveDownViewToOriginalLocation;
@end

@implementation OrdersTabViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
        }
        else {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
        }
        self.navigationItem.title = NSLocalizedString(@"Orders", @"Orders");
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    // setup the loading indicator
    loadingIndicator = [[MBProgressHUD alloc] initWithView:self.view];
    [loadingIndicator setLabelText:@"Logging in..."];
    loadingIndicator.dimBackground = YES;
    [self.view addSubview:loadingIndicator];
    
    // set up for remember button
    if ([[NSFileManager defaultManager] fileExistsAtPath:REMEMBER_USER]) {
        NSDictionary *rememberCheckboxDict = [NSDictionary dictionaryWithContentsOfFile:REMEMBER_USER];
        if (rememberCheckboxDict) {
            usernameTF.text = [rememberCheckboxDict objectForKey:@"username"];
            if ([[rememberCheckboxDict objectForKey:@"isOn"] isEqualToString:@"YES"] ) {
                [rememberCheckbox setSelected:YES];
                passwordTF.text = [rememberCheckboxDict objectForKey:@"password"];
            }
        }
    }
}

- (void)viewDidUnload
{
    [usernameTF release];
    usernameTF = nil;
    [passwordTF release];
    passwordTF = nil;
    [rememberCheckbox release];
    rememberCheckbox = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [loadingIndicator release];
    [usernameTF release];
    [passwordTF release];
    [rememberCheckbox release];
    [super dealloc];
}

#pragma mark - Custom methods
- (IBAction)loginBtnTapped:(id)sender {
    [usernameTF resignFirstResponder];
    [passwordTF resignFirstResponder];
    if (rememberCheckbox.selected) {
        NSMutableDictionary *rememberCheckboxDict = [[[NSMutableDictionary alloc] init] autorelease];
        [rememberCheckboxDict setObject:@"YES" forKey:@"isOn"];
        [rememberCheckboxDict setObject:usernameTF.text forKey:@"username"];
        [rememberCheckboxDict setObject:passwordTF.text forKey:@"password"];
        [rememberCheckboxDict writeToFile:REMEMBER_USER atomically:YES];
    }
    else {
        NSMutableDictionary *rememberCheckboxDict = [[[NSMutableDictionary alloc] init] autorelease];
        [rememberCheckboxDict setObject:@"NO" forKey:@"isOn"];
        [rememberCheckboxDict setObject:usernameTF.text forKey:@"username"];
        [rememberCheckboxDict setObject:@"" forKey:@"password"];
        [rememberCheckboxDict writeToFile:REMEMBER_USER atomically:YES];
    }
    
    if ([usernameTF.text isEqualToString:@""] || [passwordTF.text isEqualToString:@""]) {
        ALERT_ERROR_WITH_TEXT(@"Username or password is null");
    }
    else {
        GetResponseXMLFromRequestString *request = [[GetResponseXMLFromRequestString alloc] init];
        request.subDelegate = self;
        request.soapMessage = [NSString stringWithFormat:@"\n"
                               "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:lox=\"http://LoxleyService/\">\n"
                               "<soapenv:Header/>\n"
                               "<soapenv:Body>\n"
                               "<lox:LoginWebUser>\n"
                               "<lox:UserName>%@</lox:UserName>\n"
                               "<lox:Password>%@</lox:Password>\n"
                               "</lox:LoginWebUser>\n"
                               "</soapenv:Body>\n"
                               "</soapenv:Envelope>\n"
                               , usernameTF.text, passwordTF.text
                               ];
        request.soapActionName = @"http://LoxleyService/LoginWebUser";
        [request getData];
        [loadingIndicator show:YES];
    }
}

- (IBAction)forgotPasswordTapped:(id)sender {
    ForgotPasswordViewController *controller = [[ForgotPasswordViewController alloc] initWithNibName:@"ForgotPasswordViewController" bundle:nil];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
}

- (IBAction)turnOffKeyboard:(id)sender {
    [sender resignFirstResponder];
}

- (void)moveUpViewToNewLocationWithPoint:(CGPoint)point {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.3];
    self.view.frame = CGRectMake(point.x, point.y, self.view.bounds.size.width, self.view.bounds.size.height);
    [UIView commitAnimations];
}

- (void)moveDownViewToOriginalLocation {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.3];
    self.view.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height);
    [UIView commitAnimations];
}

#pragma mark - GetResponseXMLFromRequestStringDelegate
- (void)connection:(GetResponseXMLFromRequestString *)conn failedLoadResponseDataFromServer:(NSError *)err {
    [conn release];
}

- (void)connection:(GetResponseXMLFromRequestString *)conn finishLoadResponseDataFromServer:(NSData *)data {
    [loadingIndicator hide:YES];
    TBXML *tbxml = [TBXML tbxmlWithXMLData:data];
    TBXMLElement *root = tbxml.rootXMLElement;
    TBXMLElement *bodyElement = [TBXML childElementNamed:@"soap:Body" parentElement:root];
    if (bodyElement) {
        TBXMLElement *responseElement = [TBXML childElementNamed:@"LoginWebUserResponse" parentElement:bodyElement];
        TBXMLElement *resultElement = [TBXML childElementNamed:@"LoginWebUserResult" parentElement:responseElement];
        NSString *userInfoString = [TBXML textForElement:resultElement];
        if (![userInfoString isEqualToString:@""] && [userInfoString rangeOfString:@","].length != 0) {
            NSArray *userInfo = [userInfoString componentsSeparatedByString:@","];
            [GlobalFunction sharedGlobalData].userID = [userInfo objectAtIndex:0];
            [GlobalFunction sharedGlobalData].userName = [userInfo objectAtIndex:1];
            
            // remove text at textfield if checkbox is uncheck
            if (!rememberCheckbox.selected) {
                usernameTF.text = @"";
                passwordTF.text = @"";
            }
            
            // then, come into app
            appDelegate.isUserLoggedIn = YES;
            HomeViewController *homeController = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
            [self.navigationController pushViewController:homeController animated:YES];
            [homeController release];
        }
        else {
            ALERT_ERROR_WITH_TEXT(@"Can not log in to system.");
        }
    }
    
    [conn release];
}

#pragma mark - TextfieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [self moveUpViewToNewLocationWithPoint:CGPointMake(0, 150-textField.frame.origin.y)];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [self moveDownViewToOriginalLocation];
}

@end

//
//  ProgressingOrdersViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "ProgressingOrdersViewController.h"
#import "AppDelegate.h"
#import "KentCustomTabbar.h"
#import "MBProgressHUD.h"
#import "DetailOrderViewController.h"

@interface ProgressingOrdersViewController ()

@end

@implementation ProgressingOrdersViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
        }
        else {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
        }
        self.navigationItem.title = NSLocalizedString(@"Orders in progress", @"Orders in progress");
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // setup the loading indicator
    loadingIndicator = [[MBProgressHUD alloc] initWithView:self.view];
    [loadingIndicator setLabelText:@"Loading..."];
    loadingIndicator.dimBackground = YES;
    [self.view addSubview:loadingIndicator];
    
    // set up back button
    UIImage *img_on = [UIImage imageNamed:@"back-button-on.png"];
    UIImage *img_off = [UIImage imageNamed:@"back-button-off.png"];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn setImage:img_off forState:UIControlStateNormal];
    [backBtn setImage:img_on forState:UIControlStateHighlighted];
    [backBtn setFrame:CGRectMake(0, 0, img_off.size.width, img_off.size.height)];
    [backBtn addTarget:self action:@selector(backButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarBtn = [[[UIBarButtonItem alloc] initWithCustomView:backBtn] autorelease];
    self.navigationItem.leftBarButtonItem = backBarBtn;
    
    // set up log out button
    UIImage *img_logout_on = [UIImage imageNamed:@"logout-on.png"];
    UIImage *img_logout_off = [UIImage imageNamed:@"logout-off.png"];
    UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [logoutBtn setImage:img_logout_off forState:UIControlStateNormal];
    [logoutBtn setImage:img_logout_on forState:UIControlStateHighlighted];
    [logoutBtn setFrame:CGRectMake(0, 0, img_logout_off.size.width, img_logout_off.size.height)];
    [logoutBtn addTarget:self action:@selector(loggoutBtnTapped:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *logoutBarBtn = [[[UIBarButtonItem alloc] initWithCustomView:logoutBtn] autorelease];
    self.navigationItem.rightBarButtonItem = logoutBarBtn;
    
    orderDataArray = [[NSMutableArray alloc] init];
    /***********/
    modal = [[SimpleOrderDataModal alloc] init];
    modal.delegate = self;
    [modal getCurrentOrderList];
    [loadingIndicator show:YES];
}

- (void)viewDidUnload
{
    [ordersTable release];
    ordersTable = nil;
    [searchedText release];
    searchedText = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [backupOrderList release];
    [orderDataArray release];
    [modal release];
    [loadingIndicator release];
    [ordersTable release];
    [searchedText release];
    [super dealloc];
}

#pragma mark - Custom methods
- (IBAction)backButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)loggoutBtnTapped:(id)sender {
    appDelegate.isUserLoggedIn = NO;
    [appDelegate.tabBarController selectTab:1];
    UINavigationController *tab1Controller = [appDelegate.tabBarController.viewControllers objectAtIndex:1];
    [tab1Controller popToRootViewControllerAnimated:YES];
}

- (IBAction)turnOffKeyboard:(id)sender {
    [sender resignFirstResponder];
}

#pragma mark - UITableViewDataSource, UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return orderDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *tableIdentifier = @"Order custom cell";
    OrderCustomCell *cell = (OrderCustomCell *)[tableView dequeueReusableCellWithIdentifier:tableIdentifier];
    if (cell == nil) {
        NSArray *nibArr = [[NSBundle mainBundle] loadNibNamed:@"OrderCustomCell" owner:nil options:nil];
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            cell = (OrderCustomCell *)[nibArr objectAtIndex:0];
        }
        else {
            cell = (OrderCustomCell *)[nibArr objectAtIndex:2];
        }
        
        cell.delegate = self;
    }
    NSInteger row = indexPath.row;
    // do somethings great here
    // ...
    SimpleOrderDataModal *obj = [orderDataArray objectAtIndex:row];
    cell.orderNumber.text = [NSString stringWithFormat:@"Order # %@", obj.orderNumber];
    cell.orderNumString = obj.orderNumber;
    cell.orderTime.text = obj.orderTime;
    cell.orderRef.text = obj.orderRef;
    cell.orderDueDate.text = obj.orderDueDate;
    cell.tag = row;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - order modal delegate
- (void)requestSuccessfullyWithDataArray:(NSArray *)responseData {
    [loadingIndicator hide:YES];
    [orderDataArray removeAllObjects];
    [orderDataArray addObjectsFromArray:responseData];
    backupOrderList = [orderDataArray copy];
    [ordersTable reloadData];
}

- (void)requestFailed {
    [loadingIndicator hide:YES];
    ALERT_ERROR_WITH_TEXT(@"Request failed.");
}

#pragma mark - custom cell delegate
- (void)orderCell:(OrderCustomCell *)cell didSelectOrderWithNumber:(NSString *)orderNumerStr {
    DetailOrderViewController *detailController = [[DetailOrderViewController alloc] initWithNibName:@"DetailOrderViewController" bundle:nil];
    detailController.isCompletedInvoice = NO;
    detailController.currentOrder = [orderDataArray objectAtIndex:cell.tag];
    [self.navigationController pushViewController:detailController animated:YES];
    [detailController release];
}

#pragma mark - text field delegate
//- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
//    NSLog(@"test");
//    return YES;
//}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [orderDataArray removeAllObjects];
    [orderDataArray addObjectsFromArray:backupOrderList];
    if (![textField.text isEqualToString:@""]) {
        for (NSInteger i=orderDataArray.count-1; i>=0; i--) {
            SimpleOrderDataModal *obj = [orderDataArray objectAtIndex:i];
            if (([obj.orderRef rangeOfString:searchedText.text options:NSCaseInsensitiveSearch].location == NSNotFound) && ([obj.orderNumber rangeOfString:searchedText.text options:NSCaseInsensitiveSearch].location == NSNotFound)) {
                [orderDataArray removeObject:obj];
            }
        }
    }
    [ordersTable reloadData];
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    [orderDataArray removeAllObjects];
    [orderDataArray addObjectsFromArray:backupOrderList];
    [ordersTable reloadData];
    return YES;
}

@end

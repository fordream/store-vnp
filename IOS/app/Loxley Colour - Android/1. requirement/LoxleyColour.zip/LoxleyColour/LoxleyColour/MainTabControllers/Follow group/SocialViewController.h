//
//  SocialViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/8/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@class AppDelegate;

@interface SocialViewController : UIViewController <UIWebViewDelegate> {
    MBProgressHUD *loadingIndicator;
    IBOutlet UIWebView *socialWebView;
    NSString *stringURL;
    UIBarButtonItem *logoutBarBtn;
    AppDelegate *appDelegate;
}

@property (retain, nonatomic) NSString *stringURL;

@end

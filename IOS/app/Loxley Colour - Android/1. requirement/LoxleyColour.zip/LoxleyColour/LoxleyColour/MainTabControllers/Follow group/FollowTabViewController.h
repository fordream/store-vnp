//
//  FollowTabViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;

@interface FollowTabViewController : UIViewController {
    UIBarButtonItem *logoutBarBtn;
    AppDelegate *appDelegate;
}

- (IBAction)followUsBtnTapped:(id)sender;
- (IBAction)likeUsBtnTapped:(id)sender;
- (IBAction)visitUsBtnTapped:(id)sender;

@end

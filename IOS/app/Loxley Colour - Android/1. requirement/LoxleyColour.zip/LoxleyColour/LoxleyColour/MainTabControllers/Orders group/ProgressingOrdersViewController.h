//
//  ProgressingOrdersViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SimpleOrderDataModal.h"
#import "OrderCustomCell.h"

@class AppDelegate;
@class MBProgressHUD;

@interface ProgressingOrdersViewController : UIViewController <UITextFieldDelegate, SimpleOrderDataModalDelegate, OrderCustomCellDelegate> {
    IBOutlet UITextField *searchedText;
    IBOutlet UITableView *ordersTable;
    AppDelegate *appDelegate;
    NSMutableArray *orderDataArray;
    NSArray *backupOrderList;
    MBProgressHUD *loadingIndicator;
    SimpleOrderDataModal *modal;
}

- (IBAction)turnOffKeyboard:(id)sender;

@end

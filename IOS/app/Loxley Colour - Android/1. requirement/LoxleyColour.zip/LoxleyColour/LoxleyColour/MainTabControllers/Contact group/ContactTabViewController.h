//
//  ContactTabViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

@class AppDelegate;

@interface ContactTabViewController : UIViewController <MFMailComposeViewControllerDelegate> {
    UIBarButtonItem *logoutBarBtn;
    AppDelegate *appDelegate;
}

- (IBAction)callUsBtnTapped:(id)sender;
- (IBAction)emailUsBtnTapped:(id)sender;
- (IBAction)visitUsBtnTapped:(id)sender;

@end

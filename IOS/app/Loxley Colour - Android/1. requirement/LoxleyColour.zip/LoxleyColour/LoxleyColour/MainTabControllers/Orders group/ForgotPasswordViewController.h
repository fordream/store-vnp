//
//  ForgotPasswordViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/8/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GetResponseXMLFromRequestString.h"
#import "MBProgressHUD.h"

@interface ForgotPasswordViewController : UIViewController <GetResponseXMLFromRequestStringDelegate, UIWebViewDelegate> {
    IBOutlet UITextField *emailTF;
    MBProgressHUD *loadingIndicator;
    IBOutlet UIWebView *myWebView;
}

- (IBAction)resetPasswordTapped:(id)sender;
- (IBAction)turnOffKeyboard:(id)sender;

@end

//
//  ContactTabViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "ContactTabViewController.h"
#import "AppDelegate.h"
#import "KentCustomTabbar.h"

@interface ContactTabViewController ()

@end

@implementation ContactTabViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = NSLocalizedString(@"Contact", @"Contact");
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
    }
    else {
        self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
    }
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate addObserver:self forKeyPath:@"isUserLoggedIn" options:(NSKeyValueObservingOptionNew) context:NULL];
    // set up log out button
    UIImage *img_on = [UIImage imageNamed:@"logout-on.png"];
    UIImage *img_off = [UIImage imageNamed:@"logout-off.png"];
    UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [logoutBtn setImage:img_off forState:UIControlStateNormal];
    [logoutBtn setImage:img_on forState:UIControlStateHighlighted];
    [logoutBtn setFrame:CGRectMake(0, 0, img_off.size.width, img_off.size.height)];
    [logoutBtn addTarget:self action:@selector(loggoutBtnTapped:) forControlEvents:UIControlEventTouchUpInside];
    logoutBarBtn = [[UIBarButtonItem alloc] initWithCustomView:logoutBtn];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [appDelegate removeObserver:self forKeyPath:@"isUserLoggedIn"];
    [logoutBarBtn release];
    [super dealloc];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if (appDelegate.isUserLoggedIn) {
        self.navigationItem.rightBarButtonItem = logoutBarBtn;
    }
    else {
        self.navigationItem.rightBarButtonItem = nil;
    }
}

#pragma mark - Custom methods
- (IBAction)callUsBtnTapped:(id)sender {
    NSString *aPhoneNo = [@"tel://" stringByAppendingString:@"08455195000"]; 
    NSURL *url= [NSURL URLWithString:aPhoneNo];
    
    NSString *osVersion = [[UIDevice currentDevice] systemVersion];
    
    if ([osVersion floatValue] >= 3.1) { 
        UIWebView *webview = [[UIWebView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame]; 
        [webview loadRequest:[NSURLRequest requestWithURL:url]]; 
        webview.hidden = YES; 
        // Assume we are in a view controller and have access to self.view 
        [self.view addSubview:webview]; 
        [webview release]; 
    } else { 
        // On 3.0 and below, dial as usual 
        [[UIApplication sharedApplication] openURL: url];
    }
}

- (IBAction)emailUsBtnTapped:(id)sender {
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
        mailController.mailComposeDelegate = self;
        [mailController setToRecipients:[NSArray arrayWithObjects:@"cs@loxleycolour.com", nil]];
        [mailController setSubject:@"Support:"];
        [self presentModalViewController:mailController animated:YES];
        [mailController release];
    }
    else {
        ALERT_ERROR_WITH_TEXT(@"No email account in your device.");
    }
}

- (IBAction)visitUsBtnTapped:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://loxleycolour.com"]]];
}

- (IBAction)loggoutBtnTapped:(id)sender {
    appDelegate.isUserLoggedIn = NO;
    [appDelegate.tabBarController selectTab:1];
    UINavigationController *tab1Controller = [appDelegate.tabBarController.viewControllers objectAtIndex:1];
    [tab1Controller popToRootViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    [controller dismissModalViewControllerAnimated:YES];
}

@end

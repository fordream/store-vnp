//
//  TrackViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CompletedInvoiceDataModal;
@class MBProgressHUD;

@interface TrackViewController : UIViewController {
    CompletedInvoiceDataModal *currentOrder;
    IBOutlet UILabel *orderNumber;
    IBOutlet UILabel *orderDueDate;
    IBOutlet UILabel *orderRef;
    IBOutlet UIWebView *myWebView;
    MBProgressHUD *loadingIndicator;
    IBOutlet UILabel *trackNoLabel;
}

@property (assign, nonatomic) CompletedInvoiceDataModal *currentOrder;

@end

//
//  ForgotPasswordViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/8/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "ForgotPasswordViewController.h"

@interface ForgotPasswordViewController ()
- (void)moveUpViewToNewLocationWithPoint:(CGPoint)point;
- (void)moveDownViewToOriginalLocation;
@end

@implementation ForgotPasswordViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
        }
        else {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
        }
        self.navigationItem.title = NSLocalizedString(@"Orders", @"Orders");
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    // set up back button
    UIImage *img_on = [UIImage imageNamed:@"back-button-on.png"];
    UIImage *img_off = [UIImage imageNamed:@"back-button-off.png"];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn setImage:img_off forState:UIControlStateNormal];
    [backBtn setImage:img_on forState:UIControlStateHighlighted];
    [backBtn setFrame:CGRectMake(0, 0, img_off.size.width, img_off.size.height)];
    [backBtn addTarget:self action:@selector(backButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarBtn = [[[UIBarButtonItem alloc] initWithCustomView:backBtn] autorelease];
    self.navigationItem.leftBarButtonItem = backBarBtn;
    
    // setup the loading indicator
    loadingIndicator = [[MBProgressHUD alloc] initWithView:self.view];
    [loadingIndicator setLabelText:@"Sending..."];
    loadingIndicator.dimBackground = YES;
    [self.view addSubview:loadingIndicator];
    [myWebView setDelegate:self];
    [myWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://www.loxleycolour.com/login.aspx"]]]];
    [myWebView setScalesPageToFit:YES];

}
- (void)webViewDidStartLoad: (UIWebView *)webView 
{
    // starting the load, show the activity indicator in the status bar
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:FALSE];
	
}
- (void)viewDidUnload
{
    [emailTF release];
    emailTF = nil;
    [myWebView release];
    myWebView = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [loadingIndicator release];
    [emailTF release];
    [myWebView release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Custom methods
- (IBAction)backButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)resetPasswordTapped:(id)sender {
    NSLog(@"%@",emailTF.text);
    if ([emailTF.text isEqualToString:@""]) {
        ALERT_ERROR_WITH_TEXT(@"Email field can not be null.");
    }
    else {
        GetResponseXMLFromRequestString *request = [[GetResponseXMLFromRequestString alloc] init];
        request.subDelegate = self;
        request.soapMessage = [NSString stringWithFormat:@"\n"
                               "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:lox=\"http://LoxleyService/\">\n"
                               "<soapenv:Header/>\n"
                               "<soapenv:Body>\n"
                               "<lox:SendUserAndPassword>\n"
                               "<lox:EmailAddress>%@</lox:EmailAddress>\n"
                               "</lox:SendUserAndPassword>\n"
                               "</soapenv:Body>\n"
                               "</soapenv:Envelope>\n"
                               , emailTF.text
                               ];
        request.soapActionName = @"http://LoxleyService/SendUserAndPassword";
        [request getData];
        [loadingIndicator show:YES];
    }
}

- (IBAction)turnOffKeyboard:(id)sender {
    [sender resignFirstResponder];
}

- (void)moveUpViewToNewLocationWithPoint:(CGPoint)point {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.3];
    self.view.frame = CGRectMake(point.x, point.y, self.view.bounds.size.width, self.view.bounds.size.height);
    [UIView commitAnimations];
}

- (void)moveDownViewToOriginalLocation {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.3];
    self.view.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height);
    [UIView commitAnimations];
}

#pragma mark - TextfieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [self moveUpViewToNewLocationWithPoint:CGPointMake(0, 150-textField.frame.origin.y)];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [self moveDownViewToOriginalLocation];
}

#pragma mark - GetResponseXMLFromRequestStringDelegate
- (void)connection:(GetResponseXMLFromRequestString *)conn failedLoadResponseDataFromServer:(NSError *)err {
    [conn release];
}

- (void)connection:(GetResponseXMLFromRequestString *)conn finishLoadResponseDataFromServer:(NSData *)data {
    [loadingIndicator hide:YES];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Reset Password" 
                                                    message:@"A new password has been sent to your inbox." 
                                                   delegate:self 
                                          cancelButtonTitle:@"Continue" 
                                          otherButtonTitles:nil];
    [alert show];
    [alert release];
    [conn release];
}

@end

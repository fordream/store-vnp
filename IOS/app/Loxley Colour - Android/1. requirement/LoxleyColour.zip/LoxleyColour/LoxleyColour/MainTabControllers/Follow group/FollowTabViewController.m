//
//  FollowTabViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "FollowTabViewController.h"
#import "AppDelegate.h"
#import "KentCustomTabbar.h"
#import "SocialViewController.h"

@interface FollowTabViewController ()

@end

@implementation FollowTabViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = NSLocalizedString(@"Follow", @"Follow");
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
        }
        else {
            self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
        }
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate addObserver:self forKeyPath:@"isUserLoggedIn" options:(NSKeyValueObservingOptionNew) context:NULL];
    // set up log out button
    UIImage *img_on = [UIImage imageNamed:@"logout-on.png"];
    UIImage *img_off = [UIImage imageNamed:@"logout-off.png"];
    UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [logoutBtn setImage:img_off forState:UIControlStateNormal];
    [logoutBtn setImage:img_on forState:UIControlStateHighlighted];
    [logoutBtn setFrame:CGRectMake(0, 0, img_off.size.width, img_off.size.height)];
    [logoutBtn addTarget:self action:@selector(loggoutBtnTapped:) forControlEvents:UIControlEventTouchUpInside];
    logoutBarBtn = [[UIBarButtonItem alloc] initWithCustomView:logoutBtn];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [appDelegate removeObserver:self forKeyPath:@"isUserLoggedIn"];
    [logoutBarBtn release];
    [super dealloc];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if (appDelegate.isUserLoggedIn) {
        self.navigationItem.rightBarButtonItem = logoutBarBtn;
    }
    else {
        self.navigationItem.rightBarButtonItem = nil;
    }
}

#pragma mark - Custom methods
- (IBAction)followUsBtnTapped:(id)sender {
    SocialViewController *socialController = [[SocialViewController alloc] initWithNibName:@"SocialViewController" bundle:nil];
    socialController.stringURL = @"https://twitter.com/#!/loxleycolour";
    [self.navigationController pushViewController:socialController animated:YES];
    [socialController release];
}

- (IBAction)likeUsBtnTapped:(id)sender {
    SocialViewController *socialController = [[SocialViewController alloc] initWithNibName:@"SocialViewController" bundle:nil];
    socialController.stringURL = @"https://facebook.com/loxleycolour";
    [self.navigationController pushViewController:socialController animated:YES];
    [socialController release];
}

- (IBAction)visitUsBtnTapped:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://loxleycolour.com"]]];
}

- (IBAction)loggoutBtnTapped:(id)sender {
    appDelegate.isUserLoggedIn = NO;
    [appDelegate.tabBarController selectTab:1];
    UINavigationController *tab1Controller = [appDelegate.tabBarController.viewControllers objectAtIndex:1];
    [tab1Controller popToRootViewControllerAnimated:YES];
}

@end

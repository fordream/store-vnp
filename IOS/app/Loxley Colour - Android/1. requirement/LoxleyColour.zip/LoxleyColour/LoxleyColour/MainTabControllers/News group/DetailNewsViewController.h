//
//  DetailNewsViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;

@interface DetailNewsViewController : UIViewController {
    UIBarButtonItem *logoutBarBtn;
    AppDelegate *appDelegate;
}

@end

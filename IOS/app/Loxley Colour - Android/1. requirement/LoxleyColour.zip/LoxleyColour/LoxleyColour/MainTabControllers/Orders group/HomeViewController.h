//
//  HomeViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/8/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;

@interface HomeViewController : UIViewController {
    AppDelegate *appDelegate;
}

- (IBAction)orderInProgressTapped:(id)sender;
- (IBAction)completedOrdersTapped:(id)sender;

@end

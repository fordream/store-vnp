//
//  TrackViewController.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "TrackViewController.h"
#import "CompletedInvoiceDataModal.h"
#import "MBProgressHUD.h"

@interface TrackViewController ()

@end

@implementation TrackViewController
@synthesize currentOrder;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        nibNameOrNil = [nibNameOrNil stringByAppendingString:@"_iPad"];
    }
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND];
    }
    else {
        self.view.backgroundColor = [UIColor colorWithPatternImage:VIEW_BACKGROUND_IPAD];
    }
    self.navigationItem.title = NSLocalizedString(@"Completed orders", @"Completed orders");
     
    // setup the loading indicator
    loadingIndicator = [[MBProgressHUD alloc] initWithView:self.view];
    [loadingIndicator setLabelText:@"Loading..."];
    loadingIndicator.dimBackground = YES;
    [self.view addSubview:loadingIndicator];
    
    // set up back button 
    UIImage *img_on = [UIImage imageNamed:@"back-button-on.png"];
    UIImage *img_off = [UIImage imageNamed:@"back-button-off.png"];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn setImage:img_off forState:UIControlStateNormal];
    [backBtn setImage:img_on forState:UIControlStateHighlighted];
    [backBtn setFrame:CGRectMake(0, 0, img_off.size.width, img_off.size.height)];
    [backBtn addTarget:self action:@selector(backButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarBtn = [[[UIBarButtonItem alloc] initWithCustomView:backBtn] autorelease];
    self.navigationItem.leftBarButtonItem = backBarBtn;
    
    // load data to view
    orderNumber.text = [NSString stringWithFormat:@"Order # %@", currentOrder.orderNumber];
    orderDueDate.text = [NSString stringWithFormat:@"Due date: %@", currentOrder.orderDueDate];
    orderRef.text = [NSString stringWithFormat:@"Reference: %@", currentOrder.orderRef];
    trackNoLabel.text = [NSString stringWithFormat:@"Track No.: %@", currentOrder.trackNumber];
    
    /********/
    NSURL *myURL = [NSURL URLWithString:[NSString stringWithFormat:@"http://track2.royalmail.com/portal/rm/track?trackNumber=%@", currentOrder.trackNumber]];
    NSLog(@"%@", myURL);
    [myWebView loadRequest:[NSURLRequest requestWithURL:myURL]];
}

- (void)viewDidUnload
{
    [orderNumber release];
    orderNumber = nil;
    [orderDueDate release];
    orderDueDate = nil;
    [orderRef release];
    orderRef = nil;
    [myWebView release];
    myWebView = nil;
    [trackNoLabel release];
    trackNoLabel = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [loadingIndicator release];
    [orderNumber release];
    [orderDueDate release];
    [orderRef release];
    [myWebView release];
    [trackNoLabel release];
    [super dealloc];
}

#pragma mark - Custom methods
- (IBAction)backButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - webview delegate
- (void)webViewDidStartLoad:(UIWebView *)webView {
    [loadingIndicator show:YES];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [loadingIndicator hide:YES];
    [webView stringByEvaluatingJavaScriptFromString:@"window.scroll(200,220)"];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    [loadingIndicator hide:YES];
}

@end

//
//  NewsTabViewController.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsCustomCell.h"

@class AppDelegate;

@interface NewsTabViewController : UIViewController <NewsCustomCellDelegate> {
    UIBarButtonItem *logoutBarBtn;
    AppDelegate *appDelegate;
    NSMutableArray *newsDataArray;
    IBOutlet UITableView *newsTable;
    IBOutlet UIWebView* ui_wNews;
}
@property (nonatomic,retain) UIWebView* ui_wNews;
@end


//
//  SplashView.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/13/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "SplashView.h"

@implementation SplashView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Default.png"]];
        }
        else {
            self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Default-Portrait~ipad.png"]];
        }
        
        self.alpha = 1.0;
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)makeAnimationWhenDisappear {
    [self performSelector:@selector(destroyItself) withObject:nil afterDelay:2.5];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2.0];
    self.alpha = 0.0;
    [UIView commitAnimations];
}

- (void)destroyItself {
    [self removeFromSuperview];
}

@end

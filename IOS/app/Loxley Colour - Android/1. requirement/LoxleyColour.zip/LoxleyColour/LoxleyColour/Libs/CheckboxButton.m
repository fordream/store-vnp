//
//  CheckboxButton.m
//  ZiweiAstrology
//
//  Created by Kent Vu on 3/5/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "CheckboxButton.h"

@implementation CheckboxButton
@synthesize subDelegate;
@synthesize savingText;

- (void)dealloc
{
    [savingText release];
    [super dealloc];
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self setImage:[UIImage imageNamed:@"off.png"] forState:UIControlStateNormal];
        [self setImage:[UIImage imageNamed:@"on.png"] forState:UIControlStateSelected];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setImage:[UIImage imageNamed:@"off.png"] forState:UIControlStateNormal];
        [self setImage:[UIImage imageNamed:@"on.png"] forState:UIControlStateSelected];
    }
    return self;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    self.selected = !self.selected;
    if (self.subDelegate) {
        [self.subDelegate checkbox:self didSelected:self.selected];
    }
}

@end

//
//  KentCustomTabbar.m
//  PRICE COMPARISON
//
//  Created by Kent2508 on 8/2/11.
//  Copyright 2011 __CNC Corporation__. All rights reserved.
//

#import "KentCustomTabbar.h"
@interface KentCustomTabbar (private)
- (void)highlightTabBtn:(UIButton *)btn;
- (CGRect)frameForTabAtIndex:(NSInteger)index;
- (UIImage *)offImageForTabAtIndex:(NSInteger)index;
- (UIImage *)onImageForTabAtIndex:(NSInteger)index;

@end

@implementation KentCustomTabbar

@synthesize btn1, btn2, btn3, btn4;
@synthesize deviceType;

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
	[self hideTabBar];
	[self addCustomElements];
}

- (void)hideTabBar {
	for(UIView *view in self.view.subviews)
	{
		if([view isKindOfClass:[UITabBar class]])
		{
			view.hidden = YES;
			break;
		}
	}
}

- (void)hideNewTabBar {
//	bgTabbar.hidden = 1;
    self.btn1.hidden = 1;
    self.btn2.hidden = 1;
    self.btn3.hidden = 1;
    self.btn4.hidden = 1;
}

- (void)showNewTabBar {
//	bgTabbar.hidden = 0;
    self.btn1.hidden = 0;
    self.btn2.hidden = 0;
    self.btn3.hidden = 0;
    self.btn4.hidden = 0;
}

- (CGRect)frameForTabAtIndex:(NSInteger)index {
    CGRect rect;
    if (deviceType == 0) {
        rect = CGRectMake(80*index, 431, 80, 49);
    }
    else {
        switch (index) {
            case 0:
                rect = CGRectMake(0, 919, 256, 105);
                break;
            case 1:
                rect = CGRectMake(256, 919, 128, 105);
                break;
            case 2:
                rect = CGRectMake(256+128, 919, 128, 105);
                break;
                
            default:
                rect = CGRectMake(256+128*2, 919, 256, 105);
                break;
        }
    }
    return rect;
}

- (UIImage *)offImageForTabAtIndex:(NSInteger)index {
    UIImage *img;
    if (deviceType == 0) {
        img = [UIImage imageNamed:[NSString stringWithFormat:@"tab%d_off.png", index+1]];
    }
    else {
        img = [UIImage imageNamed:[NSString stringWithFormat:@"tab%d_off~ipad.png", index+1]];
    }
    return img;
}

- (UIImage *)onImageForTabAtIndex:(NSInteger)index {
    UIImage *img;
    if (deviceType == 0) {
        img = [UIImage imageNamed:[NSString stringWithFormat:@"tab%d_on.png", index+1]];
    }
    else {
        img = [UIImage imageNamed:[NSString stringWithFormat:@"tab%d_on~ipad.png", index+1]];
    }
    return img;
}

-(void)addCustomElements {
	// add background image (if needed)
//	bgTabbar = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tabbarBackground.png"]];
//	bgTabbar.frame = CGRectMake(0, 431, 320, 49);
//	[self.view addSubview:bgTabbar];
//	[bgTabbar release];
    
	// Initialise our two images
	UIImage *btnImage = [self offImageForTabAtIndex:0];
	UIImage *btnImageSelected = [self onImageForTabAtIndex:0];
	self.btn1 = [UIButton buttonWithType:UIButtonTypeCustom];                   // Setup the button
	btn1.frame = [self frameForTabAtIndex:0];                                   // Set the frame (size and position) of the button)
	[btn1 setBackgroundImage:btnImage forState:UIControlStateNormal];           // Set the image for the normal state of the button
	[btn1 setBackgroundImage:btnImageSelected forState:UIControlStateSelected]; // Set the image for the selected state of the button
	[btn1 setTag:0];                                                            // Assign the button a "tag" so when our "click" event is called we know which button was pressed.
	[btn1 setSelected:true];                                                    // Set this button as selected (we will select the others to false as we only want Tab 1 to be selected initially
	
	// Now we repeat the process for the other buttons
	btnImage = [self offImageForTabAtIndex:1];
	btnImageSelected = [self onImageForTabAtIndex:1];
	self.btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
	btn2.frame = [self frameForTabAtIndex:1];
	[btn2 setBackgroundImage:btnImage forState:UIControlStateNormal];
	[btn2 setBackgroundImage:btnImageSelected forState:UIControlStateSelected];
	[btn2 setTag:1];
	
	btnImage = [self offImageForTabAtIndex:2];
	btnImageSelected = [self onImageForTabAtIndex:2];
	self.btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
	btn3.frame = [self frameForTabAtIndex:2];
	[btn3 setBackgroundImage:btnImage forState:UIControlStateNormal];
	[btn3 setBackgroundImage:btnImageSelected forState:UIControlStateSelected];
	[btn3 setTag:2];
	
	btnImage = [self offImageForTabAtIndex:3];
	btnImageSelected = [self onImageForTabAtIndex:3];
	self.btn4 = [UIButton buttonWithType:UIButtonTypeCustom];
	btn4.frame = [self frameForTabAtIndex:3];
	[btn4 setBackgroundImage:btnImage forState:UIControlStateNormal];
	[btn4 setBackgroundImage:btnImageSelected forState:UIControlStateSelected];
	[btn4 setTag:3];
	
	// Setup event handlers so that the buttonClicked method will respond to the touch up inside event.
	[btn1 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
	[btn2 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
	[btn3 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
	[btn4 addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    // Add my new buttons to the view
	[self.view addSubview:btn1];
	[self.view addSubview:btn2];
	[self.view addSubview:btn3];
	[self.view addSubview:btn4];
    
    btnArray = [[NSArray alloc] initWithObjects:btn1, btn2, btn3, btn4, nil];
}

- (void)buttonClicked:(id)sender {
	int tagNum = [sender tag];
	[self selectTab:tagNum]; // this is the most important command to select what you need
}

- (void)selectTab:(int)tabID {
	switch(tabID)
	{
		case 0:
			[self highlightTabBtn:btn1];
			break;
		case 1:
			[self highlightTabBtn:btn2];
			break;
		case 2:
			[self highlightTabBtn:btn3];
			break;
		case 3:
			[self highlightTabBtn:btn4];
			break;
	}	
	self.selectedIndex = tabID;
}

-(void)deselectTabs {
    for (UIButton *button in btnArray) {
        [button setSelected:FALSE];
    }
}

- (void)highlightTabBtn:(UIButton *)btn {
    for (UIButton *button in btnArray) {
        if (button == btn) {
            [button setSelected:TRUE];
        }
        else {
            [button setSelected:FALSE];
        }
    }
}

- (void)dealloc {
	[btn1 release];
	[btn2 release];
	[btn3 release];
	[btn4 release];
    [btnArray release];
    [super dealloc];
}

@end

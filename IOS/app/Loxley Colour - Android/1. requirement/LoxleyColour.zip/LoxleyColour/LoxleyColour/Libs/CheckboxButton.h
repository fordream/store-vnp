//
//  CheckboxButton.h
//  ZiweiAstrology
//
//  Created by Kent Vu on 3/5/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//
//  This custom control was created for iOS Team of FreeWjngs Group.
//  If you guys wanna use it, please dont remove this comments
//  ...
#import <UIKit/UIKit.h>
@class CheckboxButton;
@protocol CheckboxButtonDelegate <NSObject>
//  using it to know when chechbox is tapped
- (void)checkbox:(CheckboxButton *)checkboxBtn didSelected:(BOOL)selected;
@end

@interface CheckboxButton : UIButton {
    // define checkbox delegate
    id<CheckboxButtonDelegate> subDelegate;
    // saving anything you want in text
    NSString *savingText;
}

@property (nonatomic, assign) id<CheckboxButtonDelegate> subDelegate;
@property (nonatomic, retain) NSString *savingText;

@end

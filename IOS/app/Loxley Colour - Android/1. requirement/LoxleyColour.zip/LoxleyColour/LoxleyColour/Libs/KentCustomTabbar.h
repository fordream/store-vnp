//
//  KentCustomTabbar.h
//  PRICE COMPARISON
//
//  Created by Kent2508 on 8/2/11.
//  Copyright 2011 __CNC Corporation__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KentCustomTabbar : UITabBarController {
//	UIImageView *bgTabbar;
	UIButton *btn1;
	UIButton *btn2;
	UIButton *btn3;
	UIButton *btn4;
    NSArray *btnArray;
    BOOL deviceType;
}

@property (nonatomic, retain) UIButton *btn1;
@property (nonatomic, retain) UIButton *btn2;
@property (nonatomic, retain) UIButton *btn3;
@property (nonatomic, retain) UIButton *btn4;
@property (nonatomic) BOOL deviceType;

-(void) hideTabBar;
-(void) addCustomElements;
-(void) selectTab:(int)tabID;
-(void) deselectTabs;

-(void) hideNewTabBar;
-(void) showNewTabBar;

@end

//
//  SplashView.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/13/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashView : UIView

- (void)makeAnimationWhenDisappear;

@end

//
//  SimpleOrderDataModal.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "SimpleOrderDataModal.h"
#import "TBXML.h"

@implementation SimpleOrderDataModal
@synthesize orderRef, orderTime, orderNumber, orderDueDate;
@synthesize delegate;

- (void)dealloc
{
    [orderNumber release];
    [orderDueDate release];
    [orderRef release];
    [orderTime release];
    [super dealloc];
}

- (id)init {
    self = [super init];
    if (self) {
        //  set up somethings advantage here
        //  ...
    }
    return self;
}

- (void)getCurrentOrderList {
    GetResponseXMLFromRequestString *request = [[GetResponseXMLFromRequestString alloc] init];
    request.subDelegate = self;
    request.soapMessage = [NSString stringWithFormat:@"\n"
                           "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:lox=\"http://LoxleyService/\">\n"
                           "<soapenv:Header/>\n"
                           "<soapenv:Body>\n"
                           "<lox:GetMyCurrentOrders>\n"
                           "<lox:AccountID>%@</lox:AccountID>\n"
                           "<lox:PageID>0</lox:PageID>\n"
                           "<lox:SearchString></lox:SearchString>\n"
                           "<lox:StartDate>1900-01-01T00:00:00.0000</lox:StartDate>\n"
                           "<lox:EndDate>1900-01-01T00:00:00.0000</lox:EndDate>\n"
                           "</lox:GetMyCurrentOrders>\n"
                           "</soapenv:Body>\n"
                           "</soapenv:Envelope>\n"
                           , [GlobalFunction sharedGlobalData].userID
                           ];
    request.soapActionName = @"http://LoxleyService/GetMyCurrentOrders";
    [request getData];
}

#pragma mark - RequestDelegate
- (void)connection:(GetResponseXMLFromRequestString *)conn finishLoadResponseDataFromServer:(NSData *)data {
    if (delegate) {
        // get data
        TBXML *tbxml = [TBXML tbxmlWithXMLData:data];
        TBXMLElement *root = tbxml.rootXMLElement;
        TBXMLElement *bodyElement = [TBXML childElementNamed:@"soap:Body" parentElement:root];
        TBXMLElement *responseElement = [TBXML childElementNamed:@"GetMyCurrentOrdersResponse" parentElement:bodyElement];
        TBXMLElement *resultElement = [TBXML childElementNamed:@"GetMyCurrentOrdersResult" parentElement:responseElement];
        TBXMLElement *diffgramElement = [TBXML childElementNamed:@"diffgr:diffgram" parentElement:resultElement];
        TBXMLElement *dataSetElement = [TBXML childElementNamed:@"NewDataSet" parentElement:diffgramElement];
        TBXMLElement *myOrdersElement = [TBXML childElementNamed:@"MyOrders" parentElement:dataSetElement];
        NSMutableArray * dataArr = [[NSMutableArray alloc] init];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        while (myOrdersElement) {
            TBXMLElement *orderNumberElement = [TBXML childElementNamed:@"OrderNumber" parentElement:myOrdersElement];
            TBXMLElement *orderDateElement = [TBXML childElementNamed:@"OrderDate" parentElement:myOrdersElement];
            TBXMLElement *orderRefElement = [TBXML childElementNamed:@"OrderReference" parentElement:myOrdersElement];
            TBXMLElement *orderDueDateElement = [TBXML childElementNamed:@"DueDate" parentElement:myOrdersElement];
            
            SimpleOrderDataModal *obj = [[SimpleOrderDataModal alloc] init];
            obj.orderNumber = [TBXML textForElement:orderNumberElement];
            NSString *dateStr = [TBXML textForElement:orderDateElement];
            dateStr = [dateStr substringToIndex:10];
            [formatter setDateFormat:@"yyyy-MM-dd"];
            NSDate *refDate = [formatter dateFromString:dateStr];
            [formatter setDateFormat:@"dd MMM"];
            dateStr = [formatter stringFromDate:refDate];
            obj.orderTime = dateStr;
            obj.orderRef = [TBXML textForElement:orderRefElement];
            NSString *dueDateStr = [TBXML textForElement:orderDueDateElement];
            dueDateStr = [dueDateStr substringToIndex:10];
            [formatter setDateFormat:@"yyyy-MM-dd"];
            NSDate *refDate2 = [formatter dateFromString:dueDateStr];
            [formatter setDateFormat:@"dd-MM-yyyy"];
            dueDateStr = [formatter stringFromDate:refDate2];
            obj.orderDueDate = dueDateStr;
            
            [dataArr addObject:obj];
            [obj release];
            myOrdersElement = [TBXML nextSiblingNamed:@"MyOrders" searchFromElement:myOrdersElement];
        }
        [formatter release];
        // feed data
        [delegate requestSuccessfullyWithDataArray:[dataArr autorelease]];
    }
    [conn release];
}

- (void)connection:(GetResponseXMLFromRequestString *)conn failedLoadResponseDataFromServer:(NSError *)err {
    if (delegate) {
        [delegate requestFailed];
    }
    [conn release];
}

@end

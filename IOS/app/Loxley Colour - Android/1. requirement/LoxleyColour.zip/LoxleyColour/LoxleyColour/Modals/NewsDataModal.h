//
//  NewsDataModal.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/8/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsDataModal : NSObject {
    NSString *title;
    NSString *time;
    NSString *content;
}

@property (retain, nonatomic) NSString *title;
@property (retain, nonatomic) NSString *time;
@property (retain, nonatomic) NSString *content;

+ (NSMutableArray *)feedDummyDataWithQuantity:(NSInteger)number;

@end

//
//  DetailCompletedOrderDataModal.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "DetailCompletedOrderDataModal.h"
#import "TBXML.h"
#import "OrderedItemDataModal.h"

@implementation DetailCompletedOrderDataModal
@synthesize subDelegate;

- (void)dealloc
{
    [super dealloc];
}

- (id)init {
    self = [super init];
    if (self) {
        //  set up somethings advantage here
        //  ...
    }
    return self;
}

- (void)getListItemOfCurrentInvoice:(NSString *)invoiceNum {
    GetResponseXMLFromRequestString *request = [[GetResponseXMLFromRequestString alloc] init];
    request.subDelegate = self;
    request.soapMessage = [NSString stringWithFormat:@"\n"
                           "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:lox=\"http://LoxleyService/\">\n"
                           "<soapenv:Header/>\n"
                           "<soapenv:Body>\n"
                           "<lox:GetMyInvoiceItems>\n"
                           "<lox:InvoiceNumber>%@</lox:InvoiceNumber>\n"
                           "</lox:GetMyInvoiceItems>\n"
                           "</soapenv:Body>\n"
                           "</soapenv:Envelope>\n"
                           , invoiceNum
                           ];
    request.soapActionName = @"http://LoxleyService/GetMyInvoiceItems";
    [request getData];
}

#pragma mark - request delegate
- (void)connection:(GetResponseXMLFromRequestString *)conn finishLoadResponseDataFromServer:(NSData *)data {
    if (subDelegate) {
        TBXML *tbxml = [TBXML tbxmlWithXMLData:data];
        TBXMLElement *root = tbxml.rootXMLElement;
        TBXMLElement *bodyElement = [TBXML childElementNamed:@"soap:Body" parentElement:root];
        TBXMLElement *responseElement = [TBXML childElementNamed:@"GetMyInvoiceItemsResponse" parentElement:bodyElement];
        TBXMLElement *resultElement = [TBXML childElementNamed:@"GetMyInvoiceItemsResult" parentElement:responseElement];
        TBXMLElement *diffgramElement = [TBXML childElementNamed:@"diffgr:diffgram" parentElement:resultElement];
        TBXMLElement *dataSetElement = [TBXML childElementNamed:@"NewDataSet" parentElement:diffgramElement];
        TBXMLElement *myOrderItemElement = [TBXML childElementNamed:@"MyInvoiceItems" parentElement:dataSetElement];
        NSMutableArray *itemArr = [[NSMutableArray alloc] init];
        while (myOrderItemElement) {
            OrderedItemDataModal *obj = [[OrderedItemDataModal alloc] init];
            TBXMLElement *descElement = [TBXML childElementNamed:@"ItemDescription" parentElement:myOrderItemElement];
            TBXMLElement *quanElement = [TBXML childElementNamed:@"Quantity" parentElement:myOrderItemElement];
            TBXMLElement *costElement = [TBXML childElementNamed:@"UnitCost" parentElement:myOrderItemElement];
            TBXMLElement *discountElement = [TBXML childElementNamed:@"DiscountRate" parentElement:myOrderItemElement];
            TBXMLElement *vatElement = [TBXML childElementNamed:@"VatRate" parentElement:myOrderItemElement];
            
            obj.description = [TBXML textForElement:descElement];
            obj.quantity = [[TBXML textForElement:quanElement] floatValue];
            obj.cost = [[TBXML textForElement:costElement] floatValue];
            obj.discount = [[TBXML textForElement:discountElement] floatValue]*obj.cost/100;
            obj.valueOfVAT = [[TBXML textForElement:vatElement] floatValue];
            [obj calcTotalPayment];
            [itemArr addObject:obj];
            [obj release];
            myOrderItemElement = [TBXML nextSiblingNamed:@"MyInvoiceItems" searchFromElement:myOrderItemElement];
        }
        [subDelegate requestSuccessfullyWithListItem:[itemArr autorelease]];
    }
    [conn release];
}

- (void)connection:(GetResponseXMLFromRequestString *)conn failedLoadResponseDataFromServer:(NSError *)err {
    if (subDelegate) {
        [subDelegate requestFailed];
    }
    [conn release];
}

@end

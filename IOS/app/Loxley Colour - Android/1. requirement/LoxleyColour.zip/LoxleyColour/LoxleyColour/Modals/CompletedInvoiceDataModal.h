//
//  CompletedInvoiceDataModal.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SimpleOrderDataModal.h"
#import "GetResponseXMLFromRequestString.h"

@interface CompletedInvoiceDataModal : SimpleOrderDataModal <GetResponseXMLFromRequestStringDelegate> {
    NSString *shipmentMethod;
    NSString *trackURL;
    NSString *trackNumber;
    NSString *invoiceNumber;
    NSDate *orderDate;
}

@property (retain, nonatomic) NSString *shipmentMethod;
@property (retain, nonatomic) NSString *trackURL;
@property (retain, nonatomic) NSString *trackNumber;
@property (retain, nonatomic) NSString *invoiceNumber;
@property (retain, nonatomic) NSDate *orderDate;

- (void)getCurrentInvoiceList;

@end

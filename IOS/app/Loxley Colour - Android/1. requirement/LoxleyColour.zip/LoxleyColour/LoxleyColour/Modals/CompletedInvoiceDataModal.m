//
//  CompletedInvoiceDataModal.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "CompletedInvoiceDataModal.h"
#import "TBXML.h"

@implementation CompletedInvoiceDataModal
@synthesize shipmentMethod, trackNumber, invoiceNumber, orderDate, trackURL;

- (void)dealloc
{
    [trackURL release];
    [invoiceNumber release];
    [orderDate release];
    [shipmentMethod release];
    [trackNumber release];
    [super dealloc];
}

- (id)init {
    self = [super init];
    if (self) {
        //  set up somethings advantage here
        //  ...
    }
    return self;
}

- (void)getCurrentInvoiceList {
    GetResponseXMLFromRequestString *request = [[GetResponseXMLFromRequestString alloc] init];
    request.subDelegate = self;
    request.soapMessage = [NSString stringWithFormat:@"\n"
                           "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:lox=\"http://LoxleyService/\">\n"
                           "<soapenv:Header/>\n"
                           "<soapenv:Body>\n"
                           "<lox:GetMyCurrentInvoices>\n"
                           "<lox:AccountID>%@</lox:AccountID>\n"
                           "<lox:PageID>0</lox:PageID>\n"
                           "<lox:SearchString></lox:SearchString>\n"
                           "<lox:StartDate>1900-01-01T00:00:00.0000</lox:StartDate>\n"
                           "<lox:EndDate>1900-01-01T00:00:00.0000</lox:EndDate>\n"
                           "</lox:GetMyCurrentInvoices>\n"
                           "</soapenv:Body>\n"
                           "</soapenv:Envelope>\n"
                           , [GlobalFunction sharedGlobalData].userID
                           ];
    request.soapActionName = @"http://LoxleyService/GetMyCurrentInvoices";
    [request getData];
}

#pragma mark - RequestDelegate
- (void)connection:(GetResponseXMLFromRequestString *)conn finishLoadResponseDataFromServer:(NSData *)data {
    if (delegate) {
        // get data
        TBXML *tbxml = [TBXML tbxmlWithXMLData:data];
        TBXMLElement *root = tbxml.rootXMLElement;
        TBXMLElement *bodyElement = [TBXML childElementNamed:@"soap:Body" parentElement:root];
        TBXMLElement *responseElement = [TBXML childElementNamed:@"GetMyCurrentInvoicesResponse" parentElement:bodyElement];
        TBXMLElement *resultElement = [TBXML childElementNamed:@"GetMyCurrentInvoicesResult" parentElement:responseElement];
        TBXMLElement *diffgramElement = [TBXML childElementNamed:@"diffgr:diffgram" parentElement:resultElement];
        TBXMLElement *dataSetElement = [TBXML childElementNamed:@"NewDataSet" parentElement:diffgramElement];
        TBXMLElement *myInvoicesElement = [TBXML childElementNamed:@"MyInvoices" parentElement:dataSetElement];
        NSMutableArray * dataArr = [[NSMutableArray alloc] init];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        while (myInvoicesElement) {
            TBXMLElement *orderNumberElement = [TBXML childElementNamed:@"OrderNumber" parentElement:myInvoicesElement];
            TBXMLElement *orderDateElement = [TBXML childElementNamed:@"OrderDate" parentElement:myInvoicesElement];
            TBXMLElement *orderRefElement = [TBXML childElementNamed:@"OrderReference" parentElement:myInvoicesElement];
            TBXMLElement *orderDueDateElement = [TBXML childElementNamed:@"DueDate" parentElement:myInvoicesElement];
            TBXMLElement *shipMethodElement = [TBXML childElementNamed:@"ShippingMethod" parentElement:myInvoicesElement];
            TBXMLElement *urlElement = [TBXML childElementNamed:@"URL" parentElement:myInvoicesElement];
            TBXMLElement *trackNumElement = [TBXML childElementNamed:@"TrackingNumber" parentElement:myInvoicesElement];
            TBXMLElement *invoiceNumberElement = [TBXML childElementNamed:@"InvoiceNumber" parentElement:myInvoicesElement];
            
            CompletedInvoiceDataModal *obj = [[CompletedInvoiceDataModal alloc] init];
            obj.orderNumber = [TBXML textForElement:orderNumberElement];
            NSString *dateStr = [TBXML textForElement:orderDateElement];
            dateStr = [dateStr substringToIndex:10];
            [formatter setDateFormat:@"yyyy-MM-dd"];
            NSDate *refDate = [formatter dateFromString:dateStr];
            obj.orderDate = refDate;
            [formatter setDateFormat:@"dd MMM"];
            dateStr = [formatter stringFromDate:refDate];
            obj.orderTime = dateStr;
            obj.orderRef = [TBXML textForElement:orderRefElement];
            NSString *dueDateStr = [TBXML textForElement:orderDueDateElement];
            dueDateStr = [dueDateStr substringToIndex:10];
            [formatter setDateFormat:@"yyyy-MM-dd"];
            NSDate *refDate2 = [formatter dateFromString:dueDateStr];
            [formatter setDateFormat:@"dd-MM-yyyy"];
            dueDateStr = [formatter stringFromDate:refDate2];
            obj.orderDueDate = dueDateStr;
            obj.shipmentMethod = [TBXML textForElement:shipMethodElement];
            obj.trackNumber = [TBXML textForElement:trackNumElement];
            obj.invoiceNumber = [TBXML textForElement:invoiceNumberElement];
            obj.trackURL = @"";
            if (urlElement) {
                obj.trackURL = [TBXML textForElement:urlElement];
            }
            [dataArr addObject:obj];
            [obj release];
            myInvoicesElement = [TBXML nextSiblingNamed:@"MyInvoices" searchFromElement:myInvoicesElement];
        }
        [formatter release];
        // feed data
        [delegate requestSuccessfullyWithDataArray:[dataArr autorelease]];
    }
    [conn release];
}

- (void)connection:(GetResponseXMLFromRequestString *)conn failedLoadResponseDataFromServer:(NSError *)err {
    if (delegate) {
        [delegate requestFailed];
    }
    [conn release];
}

@end

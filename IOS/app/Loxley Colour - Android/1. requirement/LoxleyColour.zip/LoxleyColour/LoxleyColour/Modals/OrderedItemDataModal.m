//
//  OrderedItemDataModal.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "OrderedItemDataModal.h"

@implementation OrderedItemDataModal
@synthesize description;
@synthesize quantity;
@synthesize cost;
@synthesize discount;
@synthesize valueOfVAT;
@synthesize totalPayment;

- (void)dealloc
{
    [description release];
    [super dealloc];
}

- (id)init {
    self = [super init];
    if (self) {
        //  set up somethings advantage here
        //  ...
    }
    return self;
}

- (void)calcTotalPayment {
    if (self) {
        self.totalPayment = (self.cost - self.discount)*self.quantity;
    }
}

@end

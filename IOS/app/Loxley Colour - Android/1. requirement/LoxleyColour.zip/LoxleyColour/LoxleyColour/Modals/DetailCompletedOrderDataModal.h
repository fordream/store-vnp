//
//  DetailCompletedOrderDataModal.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GetResponseXMLFromRequestString.h"

@protocol DetailCompletedOrderDataModalDelegate <NSObject>

- (void)requestSuccessfullyWithListItem:(NSArray *)itemArray;
- (void)requestFailed;

@end

@interface DetailCompletedOrderDataModal : NSObject <GetResponseXMLFromRequestStringDelegate> {
    id<DetailCompletedOrderDataModalDelegate> subDelegate;
}

@property (assign, nonatomic) id<DetailCompletedOrderDataModalDelegate> subDelegate;

- (void)getListItemOfCurrentInvoice:(NSString *)invoiceNum;

@end

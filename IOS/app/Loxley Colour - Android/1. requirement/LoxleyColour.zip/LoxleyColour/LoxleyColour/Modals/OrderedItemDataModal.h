//
//  OrderedItemDataModal.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OrderedItemDataModal : NSObject {
    NSString *description;
    CGFloat quantity;
    CGFloat cost;
    CGFloat discount;
    CGFloat valueOfVAT;
    CGFloat totalPayment;
}

@property (retain, nonatomic) NSString *description;
@property (nonatomic) CGFloat quantity;
@property (nonatomic) CGFloat cost;
@property (nonatomic) CGFloat discount;
@property (nonatomic) CGFloat valueOfVAT;
@property (nonatomic) CGFloat totalPayment;

- (void)calcTotalPayment;

@end

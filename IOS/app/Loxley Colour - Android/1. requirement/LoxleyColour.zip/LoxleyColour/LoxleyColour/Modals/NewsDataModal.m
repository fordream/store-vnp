//
//  NewsDataModal.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/8/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "NewsDataModal.h"

@implementation NewsDataModal
@synthesize title, time, content;

- (void)dealloc
{
    [title release];
    [time release];
    [content release];
    [super dealloc];
}

- (id)init {
    self = [super init];
    if (self) {
        //  set up somethings advantage here
        //  ...
    }
    return self;
}

+ (NSMutableArray *)feedDummyDataWithQuantity:(NSInteger)number {
    NSMutableArray *arr = [[NSMutableArray alloc] initWithCapacity:number];
    for (NSInteger i=0; i<number; i++) {
        NewsDataModal *obj = [[NewsDataModal alloc] init];
        obj.title = @"New Products for 2012";
        obj.time = @"30 Apr";
        obj.content = @"4 NEW PRODUCTS FOR 2012: the Print Wrap, the Float Frame, Clusters & splits and Album Bundless.";
        [arr addObject:obj];
        [obj release];
    }
    return [arr autorelease];
}

@end

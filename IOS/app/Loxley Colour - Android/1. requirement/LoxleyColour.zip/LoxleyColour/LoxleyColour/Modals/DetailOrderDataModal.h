//
//  DetailOrderDataModal.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GetResponseXMLFromRequestString.h"

@protocol DetailOrderDataModalDelegate <NSObject>

- (void)requestSuccessfullyWithInfo:(NSDictionary *)infoDict;
- (void)requestSuccessfullyWithListItem:(NSArray *)itemArray;
- (void)requestFailed;

@end

@interface DetailOrderDataModal : NSObject <GetResponseXMLFromRequestStringDelegate> {
    id<DetailOrderDataModalDelegate> subDelegate;
}

@property (assign, nonatomic) id<DetailOrderDataModalDelegate> subDelegate;

- (void)getInfoOfCurrentOrder:(NSString *)orderNum;
- (void)getListItemOfCurrentOrder:(NSString *)orderNum;

@end

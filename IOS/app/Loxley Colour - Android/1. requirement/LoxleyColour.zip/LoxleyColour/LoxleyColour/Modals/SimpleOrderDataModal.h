//
//  SimpleOrderDataModal.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GetResponseXMLFromRequestString.h"

@protocol SimpleOrderDataModalDelegate <NSObject>

- (void)requestSuccessfullyWithDataArray:(NSArray *)responseData;
- (void)requestFailed;

@end

@interface SimpleOrderDataModal : NSObject <GetResponseXMLFromRequestStringDelegate> {
    NSString *orderNumber;
    NSString *orderRef;
    NSString *orderTime;
    NSString *orderDueDate;
    id<SimpleOrderDataModalDelegate> delegate;
}

@property (retain, nonatomic) NSString *orderNumber;
@property (retain, nonatomic) NSString *orderRef;
@property (retain, nonatomic) NSString *orderTime;
@property (retain, nonatomic) NSString *orderDueDate;
@property (assign, nonatomic) id<SimpleOrderDataModalDelegate> delegate;

- (void)getCurrentOrderList;

@end

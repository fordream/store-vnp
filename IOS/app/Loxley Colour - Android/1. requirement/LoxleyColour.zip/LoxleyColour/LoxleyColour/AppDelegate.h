//
//  AppDelegate.h
//  LoxleyColour
//
//  Created by Kent Vu on 4/17/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KentCustomTabbar;

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate> {
    BOOL isUserLoggedIn;
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) KentCustomTabbar *tabBarController;
@property (assign, nonatomic) BOOL isUserLoggedIn;

@end

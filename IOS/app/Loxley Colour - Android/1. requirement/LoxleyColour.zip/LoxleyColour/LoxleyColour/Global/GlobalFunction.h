//
//  GlobalFunction.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/7/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GlobalFunction : NSObject {
    // global variables
    NSString *userID;
    NSString *userName;
}

@property (retain, nonatomic) NSString *userID;
@property (retain, nonatomic) NSString *userName;

+ (GlobalFunction *)sharedGlobalData;

@end

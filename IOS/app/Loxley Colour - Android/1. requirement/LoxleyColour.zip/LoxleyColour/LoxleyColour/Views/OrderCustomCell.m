//
//  OrderCustomCell.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "OrderCustomCell.h"

@implementation OrderCustomCell
@synthesize orderTime, orderNumber, orderDueDate, orderRef;
@synthesize orderNumString;
@synthesize delegate;
@synthesize trackNum;
@synthesize shipmentMethod;
@synthesize trackBtn;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc
{
    [trackBtn release];
    [orderNumString release];
    [orderRef release];
    [orderNumber release];
    [orderDueDate release];
    [orderTime release];
    [trackNum release];
    [shipmentMethod release];
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)expandBtnTapped:(id)sender {
    if (delegate) {
        [delegate orderCell:self didSelectOrderWithNumber:orderNumString];
    }
}

- (IBAction)trackBtnTapped:(id)sender {
    if (delegate) {
        [delegate orderCell:self didTrackWithNumber:self.trackNum];
    }
}

@end

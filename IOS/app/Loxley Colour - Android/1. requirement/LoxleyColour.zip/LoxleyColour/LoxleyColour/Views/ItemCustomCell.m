//
//  ItemCustomCell.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "ItemCustomCell.h"

@implementation ItemCustomCell
@synthesize desc, quan, cost, disc, tota, vVAT;

- (void)dealloc
{
    [desc release];
    [quan release];
    [cost release];
    [disc release];
    [tota release];
    [vVAT release];
    [super dealloc];
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

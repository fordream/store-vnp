//
//  OrderCustomCell.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/9/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OrderCustomCell;

@protocol OrderCustomCellDelegate <NSObject>

@optional
- (void)orderCell:(OrderCustomCell *)cell didSelectOrderWithNumber:(NSString *)orderNumerStr;
- (void)orderCell:(OrderCustomCell *)cell didTrackWithNumber:(NSString *)trackNumerStr;

@end

@interface OrderCustomCell : UITableViewCell {
    UILabel *orderNumber;
    UILabel *orderTime;
    UILabel *orderRef;
    UILabel *orderDueDate;
    NSString *orderNumString;
    id<OrderCustomCellDelegate> delegate;
    NSString *trackNum;
    UILabel *shipmentMethod;
    UIButton *trackBtn;
}

@property (retain, nonatomic) IBOutlet UILabel *orderNumber;
@property (retain, nonatomic) IBOutlet UILabel *orderTime;
@property (retain, nonatomic) IBOutlet UILabel *orderRef;
@property (retain, nonatomic) IBOutlet UILabel *orderDueDate;
@property (retain, nonatomic) NSString *orderNumString;
@property (assign, nonatomic) id<OrderCustomCellDelegate> delegate;
@property (retain, nonatomic) NSString *trackNum;
@property (retain, nonatomic) IBOutlet UILabel *shipmentMethod;
@property (retain, nonatomic) IBOutlet UIButton *trackBtn;

- (IBAction)expandBtnTapped:(id)sender;
- (IBAction)trackBtnTapped:(id)sender;

@end

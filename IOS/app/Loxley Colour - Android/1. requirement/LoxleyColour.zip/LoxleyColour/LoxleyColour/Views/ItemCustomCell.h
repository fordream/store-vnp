//
//  ItemCustomCell.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/10/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ItemCustomCell : UITableViewCell {
    UILabel *desc;
    UILabel *quan;
    UILabel *cost;
    UILabel *disc;
    UILabel *tota;
    UILabel *vVAT;
}

@property (retain, nonatomic) IBOutlet UILabel *desc;
@property (retain, nonatomic) IBOutlet UILabel *quan;
@property (retain, nonatomic) IBOutlet UILabel *cost;
@property (retain, nonatomic) IBOutlet UILabel *disc;
@property (retain, nonatomic) IBOutlet UILabel *tota;
@property (retain, nonatomic) IBOutlet UILabel *vVAT;

@end

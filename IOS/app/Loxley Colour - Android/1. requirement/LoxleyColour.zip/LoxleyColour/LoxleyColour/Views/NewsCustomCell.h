//
//  NewsCustomCell.h
//  LoxleyColor
//
//  Created by Kent Vu on 4/8/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NewsCustomCell;
@protocol NewsCustomCellDelegate <NSObject>

- (void)didDiscoverDetailLinkOfCell:(NewsCustomCell *)cell;

@end

@interface NewsCustomCell : UITableViewCell {
    UILabel *newsTitle;
    UILabel *newsTime;
    UITextView *newsContent;
    NSURL *linkURL;
    id<NewsCustomCellDelegate> delegate;
}

@property (retain, nonatomic) IBOutlet UILabel *newsTitle;
@property (retain, nonatomic) IBOutlet UILabel *newsTime;
@property (retain, nonatomic) IBOutlet UITextView *newsContent;
@property (retain, nonatomic) NSURL *linkURL;
@property (assign, nonatomic) id<NewsCustomCellDelegate> delegate;

- (IBAction)detailLinkTapped:(id)sender;

@end

//
//  NewsCustomCell.m
//  LoxleyColor
//
//  Created by Kent Vu on 4/8/12.
//  Copyright (c) 2012 FreeWjngs Group. All rights reserved.
//

#import "NewsCustomCell.h"

@implementation NewsCustomCell
@synthesize newsTime, newsTitle, newsContent, linkURL, delegate;

- (void)dealloc
{
    [linkURL release];
    [newsContent release];
    [newsTime release];
    [newsTitle release];
    [super dealloc];
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        // Initialization code
        newsTitle.adjustsFontSizeToFitWidth = NO;
        newsContent.userInteractionEnabled = NO;
        newsTitle.userInteractionEnabled = NO;
        newsTime.userInteractionEnabled = NO;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)detailLinkTapped:(id)sender {
    if (delegate) {
        [delegate didDiscoverDetailLinkOfCell:self];
    }
}

@end

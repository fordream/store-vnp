//
//  ContactModel.m
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContactModel.h"

@implementation ContactModel

- (id)init
{
    self = [super init];
    if (self != nil) {
        // Initialize parameters
        m_contactList = [[NSMutableArray alloc] init];
    }
    return self;
}

- (BOOL)addContact:(Contact *)contact
{
    [m_contactList addObject:contact];
    
    return YES;
}

- (Contact *)contactAt:(int)index
{
    return [m_contactList objectAtIndex:index];
}

- (void)clear
{
    [m_contactList removeAllObjects];
}

- (int)count
{
    return [m_contactList count];
}

@end

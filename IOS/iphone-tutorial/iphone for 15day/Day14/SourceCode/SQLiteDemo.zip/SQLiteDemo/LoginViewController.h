//
//  LoginViewController.h
//  SQLiteDemo
//
//  Created by Nguyen Duong on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *username;
@property (strong, nonatomic) IBOutlet UITextField *password;

- (IBAction)onCancelled:(id)sender;
- (IBAction)onSignedIn:(id)sender;

- (IBAction)onInputInjectionData:(id)sender;
- (IBAction)onInjectionSignedIn:(id)sender;

@end

//
//  ContactModel.h
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Contact.h"

@interface ContactModel : NSObject {
    NSMutableArray  *m_contactList;    
}

- (BOOL)addContact:(Contact *)contact;
- (Contact *)contactAt:(int)index;

- (void)clear;

- (int)count;

@end

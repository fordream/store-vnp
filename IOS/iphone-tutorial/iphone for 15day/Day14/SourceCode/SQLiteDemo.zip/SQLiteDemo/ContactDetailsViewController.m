//
//  ContactDetailsViewController.m
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContactDetailsViewController.h"
#import "ContactDAO.h"

@implementation ContactDetailsViewController

@synthesize contact = m_contact;
@synthesize name;
@synthesize address;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)onDone:sender
{
    ContactDAO *contactDAO = [[ContactDAO alloc] init];
    if (m_contact) {
        // Update contact
        m_contact.name = self.name.text;
        m_contact.address = self.address.text;
        [contactDAO updateContact:m_contact];        
    } else {
        // Add a new contact
        Contact *contact = [[Contact alloc] init];
        contact.name = self.name.text;
        contact.address = self.address.text;
        [contactDAO addContact:contact];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)onCancel:sender
{
    [self.navigationController popViewControllerAnimated:YES];    
}

#pragma mark - View lifecycle

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if (m_contact) {
        self.name.text = m_contact.name;
        self.address.text = m_contact.address;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(onDone:)];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(onCancel:)];
    self.navigationItem.title = @"Contact Details";
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return TRUE;
}

@end

//
//  DataController.m
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DataController.h"

// Database name
NSString * const CONTACT_DB_NAME = @"contacts.sql";

@implementation DataController

static DataController *_instance = nil;

+ (DataController *)instance
{
	@synchronized([DataController class]) {
		if (!_instance)
			_instance = [[self alloc] init];
        
		return _instance;
	}
}

+ (id)alloc
{
	@synchronized([DataController class]) {
		if (!_instance)
            _instance = [super alloc];
        
		return _instance;
	}
}

- (id)init
{
	if (_instance != nil) {
		// Initialize parameters
                
        BOOL res = [_instance initialize];
        if (!res)
            NSLog(@"Could not initialize the instance");
        else 
            NSLog(@"Successfully initialize the instance");
	} else 
        _instance = [super init];
        
	return _instance;
}

- (void) checkAndCreateDatabase 
{
    @try {
        // Check if the SQL database has already been saved to the users phone, if not then copy it over
        BOOL success = FALSE;
        
        // Create a FileManager object, we will use this to check the status
        // of the database and to copy it over if required
        NSFileManager *fileManager = [NSFileManager defaultManager];
        
        // Check if the database has already been created in the users filesystem
        success = [fileManager fileExistsAtPath:m_databasePath];
        
        if(!success) {
            // If not then proceed to copy the database from the application to the users filesystem
            // Get the path to the database in the application package
            NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:CONTACT_DB_NAME];
            
            // Copy the database from the package to the users filesystem
            if (![fileManager copyItemAtPath:databasePathFromApp toPath:m_databasePath error:nil]) {
                NSLog(@"Could not create database");
            }
        }
        
        // Open the database from the users filessytem
        if(!sqlite3_open([m_databasePath UTF8String], &m_database) == SQLITE_OK) {
            NSLog(@"Could not open database");
        }
    } @catch (NSException *e) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[e name] message:[e reason] delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
    }
}

- (BOOL)initialize
{
    // Setup some globals
	NSString *databaseName = CONTACT_DB_NAME;
    
	// Get the path to the documents directory and append the databaseName
	NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDir = [documentPaths objectAtIndex:0];
	m_databasePath = [documentsDir stringByAppendingPathComponent:databaseName];
    
	// Execute the "checkAndCreateDatabase" function
	[self checkAndCreateDatabase];
    
    return YES;
}

- (sqlite3 *)getDatabase
{
    return m_database;
}

- (void)dealloc
{
    sqlite3_close(m_database);
}

@end

//
//  LoginDAO.h
//  SQLiteDemo
//
//  Created by Nguyen Duong on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoginDAO : NSObject

- (BOOL)checkUsename:(NSString *)username andPassword:(NSString *)password;
- (BOOL)injectionCheckUsename:(NSString *)username andPassword:(NSString *)password;

@end

//
//  ContactDAO.h
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Contact.h"
#import "ContactModel.h"

@interface ContactDAO : NSObject

- (ContactModel *)getAllContacts;

/**
 * Add a contact to database
 * Returns TRUE if successful and then update the rss category, otherwise returns FALSE
 */
- (BOOL)addContact:(Contact *)contact;
- (BOOL)updateContact:(Contact *)contact;
- (BOOL)deleteContact:(Contact *)contact;

@end

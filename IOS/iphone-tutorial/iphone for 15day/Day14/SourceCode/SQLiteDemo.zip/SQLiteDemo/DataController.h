//
//  DataController.h
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h> // Import the SQLite database framework

@interface DataController : NSObject {
    NSString *m_databasePath;
    sqlite3 *m_database;
}

// Declare the singleton
+ (DataController *)instance;
- (sqlite3 *)getDatabase;
- (BOOL)initialize;

@end

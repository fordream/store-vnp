//
//  ContactListViewController.h
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContactModel.h"
#import "LoginViewController.h"

@interface ContactListViewController : UIViewController {
    @private
    ContactModel *m_contactModel;
    UITableView *m_contactTableView;

    LoginViewController *m_loginViewController;
}

@property (strong, nonatomic) IBOutlet UITableView *contactTableView;

- (void)refresView;
- (void)showLoginView:(BOOL)animated;

- (IBAction)addContact:(id)sender;
- (IBAction)editContactTableView:(id)sender;

@end

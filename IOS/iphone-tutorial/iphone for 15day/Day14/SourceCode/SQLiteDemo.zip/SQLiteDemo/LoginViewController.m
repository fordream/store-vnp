//
//  LoginViewController.m
//  SQLiteDemo
//
//  Created by Nguyen Duong on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LoginViewController.h"
#import "LoginDAO.h"

@implementation LoginViewController
@synthesize username;
@synthesize password;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [self setUsername:nil];
    [self setPassword:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) animateViewMove:(BOOL)up
{
    const int   movementDistance    = 95;   // tweak as needed
    const float movementDuration    = 0.3f; // tweak as needed
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"animation" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    
    self.view.frame  = CGRectOffset(self.view.frame , 0, movement);
    [UIView commitAnimations];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateViewMove:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateViewMove:NO];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return TRUE;
}

- (IBAction)onCancelled:(id)sender 
{
    exit(0);
}

- (IBAction)onSignedIn:(id)sender 
{
    LoginDAO *loginDAO = [[LoginDAO alloc] init];
    BOOL check = [loginDAO checkUsename:username.text andPassword:password.text];
    
    if (check)
        [self dismissModalViewControllerAnimated:YES];
    else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Wrong account. Please try to type another one" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alertView show];
    }
}

- (IBAction)onInputInjectionData:(id)sender
{
    self.username.text = @"\" or \"1\"=\"1";
    self.password.text = @"\" or \"1\"=\"1";
}

- (IBAction)onInjectionSignedIn:(id)sender
{
    LoginDAO *loginDAO = [[LoginDAO alloc] init];
    BOOL check = [loginDAO injectionCheckUsename:username.text andPassword:password.text];
    
    if (check)
        [self dismissModalViewControllerAnimated:YES];
    else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Wrong account. Please try to type another one" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alertView show];
    }
}

@end

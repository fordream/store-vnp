//
//  LoginDAO.m
//  SQLiteDemo
//
//  Created by Nguyen Duong on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LoginDAO.h"
#import "DataController.h"

@implementation LoginDAO

- (BOOL)checkUsename:(NSString *)username andPassword:(NSString *)password
{
    DataController *dataController = [DataController instance];
    sqlite3 *database = [dataController getDatabase];
    
    @try {
        // Avoid SQL INJECTION
        // Setup the SQL Statement and compile it for faster access
        const char *sqlString = "select count(*) from account where username = ? and password = ?";
        sqlite3_stmt *sqlStatement;
        
        if(sqlite3_prepare_v2(database, sqlString, -1, &sqlStatement, NULL) != SQLITE_OK) 
            return NO;
        
        sqlite3_bind_text(sqlStatement, 1, [username UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(sqlStatement, 2, [password UTF8String], -1, SQLITE_TRANSIENT);
        
        int counter = 0;
        if(sqlite3_step(sqlStatement) == SQLITE_ROW )
            counter  = sqlite3_column_int(sqlStatement, 0);
        
        if (counter > 0)
            return YES;
        else
            return NO;
        
        // Release the compiled statement from memory
        sqlite3_finalize(sqlStatement);
    } @catch (NSException *e) {
        return NO;
    } 
}

- (BOOL)injectionCheckUsename:(NSString *)username andPassword:(NSString *)password
{
    DataController *dataController = [DataController instance];
    sqlite3 *database = [dataController getDatabase];
    
    @try {
        // SQL INJECTION
        NSString *str = [NSString stringWithFormat:@"select count(*) from account where username = \"%@\" and password = \"%@\"", username, password];
        const char *sqlString = [str UTF8String];
        sqlite3_stmt *sqlStatement;
        
        if(sqlite3_prepare_v2(database, sqlString, -1, &sqlStatement, NULL) != SQLITE_OK) 
            return NO;
        
        int counter = 0;
        if(sqlite3_step(sqlStatement) == SQLITE_ROW )
            counter  = sqlite3_column_int(sqlStatement, 0);
        
        if (counter > 0)
            return YES;
        else
            return NO;
        
        // Release the compiled statement from memory
        sqlite3_finalize(sqlStatement);
    } @catch (NSException *e) {
        return NO;
    } 
}

@end

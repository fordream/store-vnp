//
//  ContactDetailsViewController.h
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Contact.h"

@interface ContactDetailsViewController : UIViewController {
    @private
    Contact *m_contact;
}

@property (strong, nonatomic) Contact *contact;

@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *address;

@end

//
//  ContactListViewController.m
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContactListViewController.h"
#import "ContactDetailsViewController.h"
#import "Contact.h"
#import "ContactDAO.h"

@implementation ContactListViewController

@synthesize contactTableView = m_contactTableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)refresView
{
    // Load data model from database
    ContactDAO *contactDAO = [[ContactDAO alloc] init];
    if (m_contactModel)
        [m_contactModel clear];
    m_contactModel = [contactDAO getAllContacts];
    
    [m_contactTableView reloadData];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];    
    
    [self refresView];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Show Login View
    [self showLoginView:NO];
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addContact:)];
    self.navigationItem.rightBarButtonItem = addButton;
    
    UIBarButtonItem *editButton = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonSystemItemEdit target:self action:@selector(editContactTableView:)];
    self.navigationItem.leftBarButtonItem = editButton;
    
    self.navigationItem.title = @"Contact List"; 
}

- (IBAction)addContact:(id)sender
{
    ContactDetailsViewController *contactDetailsViewController = [[ContactDetailsViewController alloc] initWithNibName:@"ContactDetailsView" bundle:nil];
    [[self navigationController] pushViewController:contactDetailsViewController animated:YES];
}

- (IBAction)editContactTableView:(id)sender
{
    Boolean editing = [self.contactTableView isEditing];
    
    UIBarButtonItem *editButton = self.navigationItem.leftBarButtonItem;
    if (editing)
        editButton.title = @"Edit";
    else 
        editButton.title = @"Done";
    
    [self.contactTableView setEditing:!editing animated:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [m_contactModel count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"ContactCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    Contact *contact = [m_contactModel contactAt:indexPath.row];
    cell.textLabel.text = contact.name;
    cell.detailTextLabel.text = contact.address;
    
    // Configure the cell.
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{    
    ContactDetailsViewController *contactDetailsViewController = [[ContactDetailsViewController alloc]initWithNibName:@"ContactDetailsView" bundle:nil];
    
    Contact *selectedContact = [m_contactModel contactAt:indexPath.row];   
    contactDetailsViewController.contact = selectedContact;
    
    [[self navigationController] pushViewController:contactDetailsViewController animated:YES];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    Contact *selectedContact = [m_contactModel contactAt:indexPath.row];  
    if (selectedContact) {
        ContactDAO *contactDAO = [[ContactDAO alloc] init];
        [contactDAO deleteContact:selectedContact];
    }
    
    [self refresView];
}

- (void)showLoginView:(BOOL)animated
{
    if (m_loginViewController == nil) {
        m_loginViewController = [[LoginViewController alloc] initWithNibName:@"LoginView" bundle:nil];        
    }
    
    [self presentModalViewController:m_loginViewController animated:animated];
}

@end

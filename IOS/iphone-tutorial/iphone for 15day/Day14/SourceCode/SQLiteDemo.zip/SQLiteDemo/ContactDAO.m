//
//  ContactDAO.m
//  SQLiteDemo
//
//  Created by raycad sun on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContactDAO.h"
#import "DataController.h"

@implementation ContactDAO

- (ContactModel *)getAllContacts
{
    ContactModel *contactModel = [[ContactModel alloc] init];
    DataController *dataController = [DataController instance];
    sqlite3 *database = [dataController getDatabase];
    
    @try {
        // Setup the SQL Statement and compile it for faster access
        const char *sqlString = "select id, name, address from contact";
        sqlite3_stmt *sqlStatement;
        int contactId;
        NSString *name, *address;
        Contact *contact;
        if(sqlite3_prepare_v2(database, sqlString, -1, &sqlStatement, NULL) == SQLITE_OK) {
            // Loop through the results and add them to the contact array
            while(sqlite3_step(sqlStatement) == SQLITE_ROW) {
                // Read the data from the result row
                contactId = [[NSString stringWithUTF8String:(char *)sqlite3_column_text(sqlStatement, 0)] intValue];
                name = [NSString stringWithUTF8String:(char *)sqlite3_column_text(sqlStatement, 1)];
                address = [NSString stringWithUTF8String:(char *)sqlite3_column_text(sqlStatement, 2)];
            
                contact = [[Contact alloc] init];
                contact.contactId = contactId;
                contact.name = name;
                contact.address = address;
            
                if ([contactModel addContact:contact]) {
                    NSLog(@"Added contact sucessfully");
                }
            }
        }
        // Release the compiled statement from memory
        sqlite3_finalize(sqlStatement);
    } @catch (NSException *e) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[e name] message:[e reason] delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return nil;
    }
    
    return contactModel;
}

- (BOOL)addContact:(Contact *)contact
{
    @try {
        DataController *dataController = [DataController instance];
        sqlite3 *database = [dataController getDatabase];
        
        const char *sqlString = "insert into contact(name, address) values(?, ?)";
        sqlite3_stmt *sqlStatement;
        if(sqlite3_prepare_v2(database, sqlString, -1, &sqlStatement, NULL) != SQLITE_OK)
            NSAssert1(0, @"Error while creating the statement. '%s'", sqlite3_errmsg(database));
        
        sqlite3_bind_text(sqlStatement, 1, [[contact name] UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(sqlStatement, 2, [[contact address] UTF8String], -1, SQLITE_TRANSIENT);
        
        if(SQLITE_DONE != sqlite3_step(sqlStatement)) {
            NSAssert1(0, @"Error while inserting data. '%s'", sqlite3_errmsg(database));
            // Release the compiled statement from memory
            sqlite3_finalize(sqlStatement);
            return NO;
        } else {
            // SQLite provides a method to get the last primary key inserted by using
            // sqlite3_last_insert_rowid
            int contactId = sqlite3_last_insert_rowid(database);
            contact.contactId = contactId;
        }
        
        // Release the compiled statement from memory
        sqlite3_finalize(sqlStatement);
    } @catch (NSException *e) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[e name] message:[e reason] delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return NO;
    }
    
    return YES;
}

- (BOOL)updateContact:(Contact *)contact
{
    @try {
        DataController *dataController = [DataController instance];
        sqlite3 *database = [dataController getDatabase];
        
        const char *sqlString = "update contact set name = ?, address = ? where id = ?";
        sqlite3_stmt *sqlStatement;
        if(sqlite3_prepare_v2(database, sqlString, -1, &sqlStatement, NULL) != SQLITE_OK)
            NSAssert1(0, @"Error while creating the statement. '%s'", sqlite3_errmsg(database));
        
        sqlite3_bind_text(sqlStatement, 1, [contact.name UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(sqlStatement, 2, [contact.address UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_int64(sqlStatement, 3, contact.contactId);
        
        if(SQLITE_DONE != sqlite3_step(sqlStatement)) {
            NSAssert1(0, @"Error while updating data. '%s'", sqlite3_errmsg(database));
            // Release the compiled statement from memory
            sqlite3_finalize(sqlStatement);
            return NO;
        } 
        
        // Release the compiled statement from memory
        sqlite3_finalize(sqlStatement);
    } @catch (NSException *e) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[e name] message:[e reason] delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return NO;
    }
    
    return YES;
}

- (BOOL)deleteContact:(Contact *)contact
{
    @try {
        DataController *dataController = [DataController instance];
        sqlite3 *database = [dataController getDatabase];
        
        const char *sqlString = "delete from contact where id = ?";
        sqlite3_stmt *sqlStatement;
        if(sqlite3_prepare_v2(database, sqlString, -1, &sqlStatement, NULL) != SQLITE_OK)
            NSAssert1(0, @"Error while creating the statement. '%s'", sqlite3_errmsg(database));
        
        sqlite3_bind_int64(sqlStatement, 1, contact.contactId);
        
        if(SQLITE_DONE != sqlite3_step(sqlStatement)) {
            NSAssert1(0, @"Error while inserting data. '%s'", sqlite3_errmsg(database));
            // Release the compiled statement from memory
            sqlite3_finalize(sqlStatement);
            return NO;
        } 
        
        // Release the compiled statement from memory
        sqlite3_finalize(sqlStatement);
    } @catch (NSException *e) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[e name] message:[e reason] delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        return NO;
    }
    
    return YES;
}

@end

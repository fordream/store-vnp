//
//  ViewController.h
//  MultipleAnimation
//
//  Created by cuong minh on 6/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic, strong) UIImageView *ball;
@property (nonatomic, assign) Boolean animating;
@end

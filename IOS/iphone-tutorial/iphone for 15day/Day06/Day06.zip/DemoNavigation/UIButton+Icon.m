//
//  UIButton+Icon.m
//  DemoNavigation
//
//  Created by cuong minh on 6/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UIButton+Icon.h"

@implementation UIButton (Icon)

@end

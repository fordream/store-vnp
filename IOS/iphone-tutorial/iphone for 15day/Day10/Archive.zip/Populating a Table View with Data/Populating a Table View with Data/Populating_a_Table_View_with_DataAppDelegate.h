//
//  Populating_a_Table_View_with_DataAppDelegate.h
//  Populating a Table View with Data
//
//  Created by Vandad Nahavandipoor on 11/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Populating_a_Table_View_with_DataViewController;

@interface Populating_a_Table_View_with_DataAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Populating_a_Table_View_with_DataViewController *viewController;

@end

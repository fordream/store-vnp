//
//  ViewController.h
//  DemoTabBar
//
//  Created by cuong minh on 6/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
